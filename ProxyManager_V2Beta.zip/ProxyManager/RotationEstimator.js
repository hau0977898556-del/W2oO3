if (!globalThis.RotationEstimator) {
  globalThis.RotationEstimator = class RotationEstimator {
    // history: mảng timestamp (ms) các lần phát hiện đổi IP, tăng dần theo thời gian
    // lastRotateAt: timestamp lần đổi IP gần nhất (dùng làm mốc đếm tới lần kế tiếp)
    constructor(history, lastRotateAt) {
      this.history = Array.isArray(history) ? history : [];
      this.lastRotateAt = lastRotateAt || null;
    }

    // cần ít nhất 2 mốc thời gian mới tính được khoảng cách trung bình
    hasEnoughData() {
      return this.history.length >= 2;
    }

    // khoảng cách trung bình giữa các lần xoay (ms)
    getAverageIntervalMs() {
      if (!this.hasEnoughData()) return null;
      let diffs = [];
      for (let i = 1; i < this.history.length; i++) {
        diffs.push(this.history[i] - this.history[i - 1]);
      }
      let sum = diffs.reduce((a, b) => a + b, 0);
      return sum / diffs.length;
    }

    // ước tính còn bao lâu tới lần xoay tiếp theo, trả về chuỗi hiển thị sẵn
    getEstimateText(now = Date.now()) {
      if (!this.hasEnoughData() || !this.lastRotateAt) {
        return "chưa đủ dữ liệu";
      }
      let avgMs = this.getAverageIntervalMs();
      let nextAt = this.lastRotateAt + avgMs;
      let remainMs = nextAt - now;

      if (remainMs <= 0) {
        return "có thể đã đến hạn xoay";
      }
      return `~${RotationEstimator.formatDuration(remainMs)} nữa`;
    }

    static formatDuration(ms) {
      let totalSec = Math.round(ms / 1000);
      let hours = Math.floor(totalSec / 3600);
      let minutes = Math.floor((totalSec % 3600) / 60);
      let seconds = totalSec % 60;

      if (hours > 0) return `${hours} giờ ${minutes} phút`;
      if (minutes > 0) return `${minutes} phút ${seconds} giây`;
      return `${seconds} giây`;
    }
  };
}
