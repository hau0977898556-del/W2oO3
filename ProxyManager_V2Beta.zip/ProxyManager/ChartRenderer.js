// ChartRenderer: vẽ area chart đường cong mượt bằng SVG thuần (không thư viện
// ngoài, vì đây là popup extension chứ không phải trang web có thể tải CDN).
// Dùng nội suy Catmull-Rom chuyển thành cubic Bezier để đường vẽ mượt qua
// đúng từng điểm dữ liệu, giống kiểu biểu đồ tham khảo Hau gửi.
if (!globalThis.ChartRenderer) {
  globalThis.ChartRenderer = (function () {
    const VIEW_W = 600;
    const PAD_LEFT = 46;
    const PAD_RIGHT = 10;
    const PAD_TOP = 14;
    const PAD_BOTTOM = 22;
    const GRID_LINES = 4; // số đường lưới ngang, không tính đường đáy

    // làm tròn giá trị max lên số "đẹp" để chia lưới dễ đọc — dùng nhiều bước
    // hơn thang 1/2/5/10 kinh điển để biểu đồ bám sát dữ liệu, đỡ để trống
    // nhiều khoảng trên đỉnh (vd 5600 -> 6000 thay vì nhảy hẳn lên 10000)
    function niceCeil(value) {
      if (!value || value <= 0) return 1;
      let exp = Math.floor(Math.log10(value));
      let base = Math.pow(10, exp);
      let steps = [1, 1.5, 2, 2.5, 3, 4, 5, 6, 7.5, 10];
      for (let s of steps) {
        if (value <= s * base) return s * base;
      }
      return 10 * base;
    }

    // catmull-rom -> cubic bezier: đường cong mượt đi qua ĐÚNG mọi điểm dữ
    // liệu (khác với bezier tự do chỉ "gần đúng"), tension mặc định (uniform)
    function smoothLinePath(pts) {
      if (pts.length < 2) return "";
      let d = `M ${pts[0].x.toFixed(2)} ${pts[0].y.toFixed(2)}`;
      for (let i = 0; i < pts.length - 1; i++) {
        let p0 = pts[i === 0 ? 0 : i - 1];
        let p1 = pts[i];
        let p2 = pts[i + 1];
        let p3 = pts[i + 2 < pts.length ? i + 2 : pts.length - 1];
        let c1x = p1.x + (p2.x - p0.x) / 6;
        let c1y = p1.y + (p2.y - p0.y) / 6;
        let c2x = p2.x - (p3.x - p1.x) / 6;
        let c2y = p2.y - (p3.y - p1.y) / 6;
        d += ` C ${c1x.toFixed(2)} ${c1y.toFixed(2)}, ${c2x.toFixed(2)} ${c2y.toFixed(2)}, ${p2.x.toFixed(2)} ${p2.y.toFixed(2)}`;
      }
      return d;
    }

    function escapeXml(str) {
      return String(str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" }[c]));
    }

    // dựng toạ độ điểm trên hệ trục SVG từ dữ liệu thô [{label, value}]
    function layoutPoints(rawPoints, height, maxVal) {
      let plotW = VIEW_W - PAD_LEFT - PAD_RIGHT;
      let plotH = height - PAD_TOP - PAD_BOTTOM;
      return rawPoints.map((p, i) => ({
        x: PAD_LEFT + (rawPoints.length === 1 ? 0 : (i / (rawPoints.length - 1)) * plotW),
        y: PAD_TOP + plotH - (maxVal === 0 ? 0 : (p.value / maxVal) * plotH),
        raw: p
      }));
    }

    // render(container, rawPoints, options) — vẽ biểu đồ vào container (1 div).
    // rawPoints: [{label: "07-08", value: number}, ...] theo thứ tự thời gian tăng dần
    // options: { height, formatValue(v) => string }
    function render(container, rawPoints, options) {
      options = options || {};
      let height = options.height || 168;
      let formatValue = options.formatValue || ((v) => String(v));

      if (!rawPoints || rawPoints.length === 0) {
        container.innerHTML = `<div class="chart-empty">chưa có dữ liệu</div>`;
        return;
      }

      let hasAnyValue = rawPoints.some((p) => p.value > 0);
      if (!hasAnyValue) {
        container.innerHTML = `<div class="chart-empty">chưa có hoạt động nào trong ${rawPoints.length} ngày qua</div>`;
        return;
      }

      let plotW = VIEW_W - PAD_LEFT - PAD_RIGHT;
      let plotH = height - PAD_TOP - PAD_BOTTOM;
      let baseY = PAD_TOP + plotH;
      let maxVal = niceCeil(Math.max(...rawPoints.map((p) => p.value)));
      let pts = layoutPoints(rawPoints, height, maxVal);

      let gradientId = "pmChartGrad" + Math.random().toString(36).slice(2, 9);

      let gridSvg = "";
      for (let i = 0; i <= GRID_LINES; i++) {
        let ratio = i / GRID_LINES;
        let y = PAD_TOP + plotH * (1 - ratio);
        let val = maxVal * ratio;
        gridSvg += `<line x1="${PAD_LEFT}" y1="${y.toFixed(2)}" x2="${VIEW_W - PAD_RIGHT}" y2="${y.toFixed(2)}" class="chart-grid-line" />`;
        gridSvg += `<text x="${PAD_LEFT - 6}" y="${(y + 3).toFixed(2)}" class="chart-axis-label" text-anchor="end">${escapeXml(formatValue(val))}</text>`;
      }

      let areaSvg = "";
      let lineSvg = "";
      if (pts.length >= 2) {
        let linePath = smoothLinePath(pts);
        let areaPath = `${linePath} L ${pts[pts.length - 1].x.toFixed(2)} ${baseY.toFixed(2)} L ${pts[0].x.toFixed(2)} ${baseY.toFixed(2)} Z`;
        areaSvg = `<path d="${areaPath}" fill="url(#${gradientId})" stroke="none" />`;
        lineSvg = `<path d="${linePath}" fill="none" class="chart-line" />`;
      }

      let dotsSvg = pts.map((p) => `
        <circle cx="${p.x.toFixed(2)}" cy="${p.y.toFixed(2)}" r="3.2" class="chart-dot">
          <title>${escapeXml(p.raw.label)}: ${escapeXml(formatValue(p.raw.value))}</title>
        </circle>
      `).join("");

      // tránh chữ đè nhau nếu quá nhiều điểm — bỏ bớt nhãn theo bước nhảy,
      // luôn giữ nhãn điểm cuối cùng (mốc "hôm nay")
      let labelStep = Math.max(1, Math.ceil(pts.length / 7));
      let labelsSvg = pts.map((p, i) => {
        if (i % labelStep !== 0 && i !== pts.length - 1) return "";
        return `<text x="${p.x.toFixed(2)}" y="${height - 5}" class="chart-axis-label" text-anchor="middle">${escapeXml(p.raw.label)}</text>`;
      }).join("");

      container.innerHTML = `
        <svg viewBox="0 0 ${VIEW_W} ${height}" class="chart-svg">
          <defs>
            <linearGradient id="${gradientId}" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="rgba(79,195,247,0.55)" />
              <stop offset="100%" stop-color="rgba(79,195,247,0.03)" />
            </linearGradient>
          </defs>
          ${gridSvg}
          ${areaSvg}
          ${lineSvg}
          ${dotsSvg}
          ${labelsSvg}
        </svg>
      `;
    }

    return { render, niceCeil, smoothLinePath, layoutPoints };
  })();
}
