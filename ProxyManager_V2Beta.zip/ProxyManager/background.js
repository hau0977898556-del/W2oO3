importScripts('ProxyConnect.js', 'ProxyProbe.js', 'MkvnChecker.js', 'ProxyRater.js');

const CHECK_ALARM = "proxyHealthCheck";
const DEFAULT_CHECK_DELAY_SEC = 30;
const MAX_ROTATE_HISTORY = 12; // chỉ giữ 12 lần xoay gần nhất để tính trung bình, tránh lệch do dữ liệu quá cũ
const STATS_RETENTION_DAYS = 30; // chỉ giữ 30 ngày gần nhất cho thống kê, tránh phình storage vô hạn
const CHART_DAYS = 7; // số ngày hiển thị trên biểu đồ, khớp với UI

// gom nhiều lần cộng dồn lại rồi mới ghi storage 1 lần, tránh ghi storage liên tục
let pendingBytes = 0;
let flushTimer = null;

// key ngày theo giờ địa phương (không phải UTC) để khớp với "hôm nay" theo
// cảm nhận của người dùng, không lệch ngày vào lúc gần nửa đêm
function dateKeyFor(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function todayKey() {
  return dateKeyFor(new Date());
}

// chỉ giữ lại N ngày gần nhất trong object thống kê theo ngày
function pruneOldDays(obj, keepDays) {
  let keys = Object.keys(obj).sort();
  if (keys.length <= keepDays) return obj;
  let pruned = { ...obj };
  keys.slice(0, keys.length - keepDays).forEach((k) => delete pruned[k]);
  return pruned;
}

// dựng chuỗi N ngày gần nhất (kể cả ngày không có dữ liệu = 0) để biểu đồ luôn
// có đủ trục ngày liên tục, không bị thiếu điểm khi có ngày không dùng proxy
function buildLastNDaysSeries(byDayObj, n) {
  let result = [];
  let now = new Date();
  for (let i = n - 1; i >= 0; i--) {
    let d = new Date(now);
    d.setDate(d.getDate() - i);
    let key = dateKeyFor(d);
    let label = `${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    result.push({ key, label, value: (byDayObj && byDayObj[key]) || 0 });
  }
  return result;
}

// xử lý auth proxy có user/pass
chrome.webRequest.onAuthRequired.addListener(
  (details, callback) => {
    chrome.storage.local.get(["user", "pass"], (data) => {
      if (data.user && data.pass) {
        callback({ authCredentials: { username: data.user, password: data.pass } });
      } else {
        callback();
      }
    });
  },
  { urls: ["<all_urls>"] },
  ["asyncBlocking"]
);

// đếm data ước tính dựa trên Content-Length của response, chỉ tính request
// thực sự đi qua proxy (đúng theo logic blacklist/whitelist đang cấu hình)
chrome.webRequest.onCompleted.addListener(
  (details) => {
    trackRequestSize(details);
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

function trackRequestSize(details) {
  chrome.storage.local.get(["status", "ruleMode", "domains"], (data) => {
    if (!data.status || !data.status.includes("Proxy working")) return;

    let host = "";
    try {
      host = new URL(details.url).hostname;
    } catch (e) {
      return;
    }

    if (!isRoutedThroughProxy(host, data.ruleMode, data.domains)) return;

    let size = getResponseSize(details.responseHeaders);
    if (size > 0) {
      pendingBytes += size;
      scheduleFlush();
    }
  });
}

// đúng logic ProxyConnect: whitelist thì chỉ domain trong danh sách đi qua proxy,
// blacklist thì mọi domain TRỪ danh sách mới đi qua proxy
function isRoutedThroughProxy(host, ruleMode, rawDomains) {
  let domains = (rawDomains || "").split(",").map(d => d.trim()).filter(d => d);
  if (domains.length === 0) return true; // không cấu hình domain => áp dụng toàn bộ

  let matched = domains.some(d => domainPatternMatches(host, d));
  if (ruleMode === "whitelist") return matched;
  return !matched; // blacklist: khớp danh sách nghĩa là bypass, không qua proxy
}

// hỗ trợ domain có "*" kiểu wildcard (vd "*.google.com") ngoài kiểu includes() cũ
function domainPatternMatches(host, pattern) {
  if (!pattern.includes("*")) return host.includes(pattern);
  let regexStr = "^" + pattern
    .split("*")
    .map(part => part.replace(/[.+?^${}()|[\]\\]/g, "\\$&"))
    .join(".*") + "$";
  return new RegExp(regexStr).test(host);
}

function getResponseSize(headers) {
  if (!headers) return 0;
  let header = headers.find(h => h.name.toLowerCase() === "content-length");
  return header ? parseInt(header.value) || 0 : 0;
}

function scheduleFlush() {
  if (flushTimer) return;
  flushTimer = setTimeout(() => {
    let toAdd = pendingBytes;
    pendingBytes = 0;
    flushTimer = null;
    chrome.storage.local.get(["dataUsedBytes", "dataUsedByDay"], (data) => {
      let total = (data.dataUsedBytes || 0) + toAdd;
      let byDay = pruneOldDays(data.dataUsedByDay || {}, STATS_RETENTION_DAYS);
      let key = todayKey();
      byDay[key] = (byDay[key] || 0) + toAdd;
      chrome.storage.local.set({ dataUsedBytes: total, dataUsedByDay: byDay });
    });
  }, 2000);
}

// ==== theo dõi thời gian kết nối proxy theo ngày, kiểu "checkpoint" ====
// mỗi lần được gọi, cộng dồn khoảng thời gian từ checkpoint gần nhất tới giờ
// vào bucket của "hôm nay" rồi dời checkpoint tới hiện tại. Cách này tự động
// xử lý luôn trường hợp phiên kết nối vắt qua nửa đêm (mỗi lần flush sẽ tự
// tính đúng cho ngày đang là "hôm nay" tại thời điểm gọi).
async function flushConnectionTime() {
  let data = await chrome.storage.local.get(["connectionCheckpointAt", "connectTimeByDay"]);
  if (!data.connectionCheckpointAt) return;

  let now = Date.now();
  let elapsedSec = Math.max(0, Math.round((now - data.connectionCheckpointAt) / 1000));
  let byDay = pruneOldDays(data.connectTimeByDay || {}, STATS_RETENTION_DAYS);
  let key = todayKey();
  byDay[key] = (byDay[key] || 0) + elapsedSec;
  await chrome.storage.local.set({ connectTimeByDay: byDay, connectionCheckpointAt: now });
}

// bắt đầu tính giờ cho 1 phiên kết nối mới
async function startConnectionTimer() {
  await chrome.storage.local.set({ connectionCheckpointAt: Date.now() });
}

// chốt sổ phần thời gian còn dang dở của phiên hiện tại rồi dừng hẳn
async function stopConnectionTimer() {
  await flushConnectionTime();
  await chrome.storage.local.set({ connectionCheckpointAt: null });
}

// ==== chặn rò rỉ khi đang dùng proxy: WebRTC + DNS prefetch ====
//
// 1) WebRTC: dù HTTP/SOCKS5 traffic đã đi qua proxy, WebRTC (video call, P2P)
// vẫn có thể tự mở kết nối UDP trực tiếp ra ngoài và lộ IP thật — leak kinh
// điển khiến các hệ thống chấm điểm proxy phát hiện ngay vì IP HTTP với IP
// WebRTC không khớp nhau. "disable_non_proxied_udp" là chế độ chuẩn mà các
// VPN/proxy extension thật (NordVPN, ExpressVPN...) đều dùng.
//
// 2) DNS prefetch: đây là lỗ hổng có THẬT và đã được nghiên cứu bảo mật xác
// nhận (Cure53 / TheBestVPN, 2018) — Chrome tự "đoán trước" domain sắp truy
// cập (gõ trên thanh địa chỉ, hoặc bật "preload pages") rồi phân giải DNS
// NGAY LẬP TỨC qua resolver hệ thống, KHÔNG qua proxy — vì HTTP proxy không
// proxy được DNS, và Chrome cũng không hỗ trợ DNS qua SOCKS. Kết quả: dù mọi
// traffic thật đã đi qua proxy, ISP/mạng cục bộ vẫn thấy được domain bạn sắp
// vào. `networkPredictionEnabled=false` tắt được phần Chrome TỰ dự đoán —
// LƯU Ý: theo chính doc của Chrome, setting này KHÔNG chặn được trang web
// chủ động nhúng <link rel="dns-prefetch">, nên đây là giảm bề mặt rò rỉ chứ
// không phải chặn tuyệt đối 100%.
async function snapshotLeakProtectionSettings() {
  let [webrtc, dnsPredict] = await Promise.all([
    new Promise((resolve) => {
      chrome.privacy.network.webRTCIPHandlingPolicy.get({}, (details) => resolve(details && details.value));
    }),
    new Promise((resolve) => {
      chrome.privacy.network.networkPredictionEnabled.get({}, (details) => resolve(details && details.value));
    })
  ]);
  return { webrtc, dnsPredict };
}

async function applyLeakProtection() {
  let settings = await chrome.storage.local.get(["webrtcProtection"]);
  if (settings.webrtcProtection === false) return; // người dùng tự tắt tính năng này

  let current = await snapshotLeakProtectionSettings();
  // chỉ lưu backup nếu CHƯA có (tránh trường hợp connect nhiều lần liên tiếp
  // ghi đè backup bằng chính giá trị mình đã set trước đó, làm mất giá trị gốc)
  let stored = await chrome.storage.local.get(["leakProtectionBackup"]);
  if (stored.leakProtectionBackup === undefined) {
    await chrome.storage.local.set({ leakProtectionBackup: current });
  }

  await Promise.all([
    new Promise((resolve) => {
      chrome.privacy.network.webRTCIPHandlingPolicy.set({ value: "disable_non_proxied_udp" }, resolve);
    }),
    new Promise((resolve) => {
      chrome.privacy.network.networkPredictionEnabled.set({ value: false }, resolve);
    })
  ]);
}

async function restoreLeakProtection() {
  let stored = await chrome.storage.local.get(["leakProtectionBackup"]);
  if (stored.leakProtectionBackup === undefined) return; // chưa từng bật, không có gì để khôi phục

  let backup = stored.leakProtectionBackup;
  await Promise.all([
    new Promise((resolve) => {
      chrome.privacy.network.webRTCIPHandlingPolicy.set({ value: backup.webrtc }, resolve);
    }),
    new Promise((resolve) => {
      chrome.privacy.network.networkPredictionEnabled.set({ value: backup.dnsPredict }, resolve);
    })
  ]);
  await chrome.storage.local.remove("leakProtectionBackup");
}

// gộp toàn bộ luồng "dò scheme (nếu auto) -> connect -> verify -> cập nhật
// status" vào MỘT chỗ chạy hẳn trong background. Lý do quan trọng: bản cũ
// verify() chạy trong popup — nếu popup đóng/mất focus giữa chừng (rất dễ
// xảy ra, vd người dùng bấm connect rồi lỡ tay click ra ngoài), toàn bộ
// promise đang chờ bị hủy theo popup, KHÔNG có status nào được ghi lại =>
// đúng triệu chứng "ngắt đột ngột, không trả về dữ liệu". Service worker
// sống độc lập với popup nên chạy ở đây an toàn hơn nhiều.
async function connectAndVerify(cfg) {
  let scheme = cfg.scheme;
  let detectLog = [];
  let detectedNeedsAuth = false;
  let apiExitIp = null; // IP thật lấy được từ mkvn lúc dò scheme (nếu có) — ưu tiên hiện cái này

  let creds = await chrome.storage.local.get(["user", "pass"]);
  // mkvn không có field auth — proxy có user/pass gửi qua đó sẽ luôn bị báo
  // DIE oan, nên có auth là bỏ qua mkvn hoàn toàn, dùng thẳng ProxyProbe local
  // (tự support auth qua onAuthRequired) để không báo sai và không lộ
  // credentials của proxy ra 1 domain thứ 3 không liên quan
  let hasAuth = !!(creds.user || creds.pass);

  if (scheme === "auto" || !scheme) {
    if (!hasAuth) {
      await chrome.storage.local.set({ status: "đang dò giao thức qua mkvn..." });
      let apiResult = await MkvnChecker.detectSchemeViaApi(cfg.ip, cfg.port);
      if (apiResult.scheme) {
        scheme = apiResult.scheme;
        apiExitIp = apiResult.exitIp;
        detectLog.push({ level: "success", text: `mkvn xác nhận ${scheme.toUpperCase()} còn sống`, at: Date.now() });
      }
    }

    // chưa tìm được scheme (có auth nên bỏ qua mkvn, hoặc mkvn báo chết cả 2,
    // hoặc mkvn tự lỗi/không phản hồi) -> dò local như cũ, cũng là nơi duy
    // nhất còn thử được "https" (mkvn không hỗ trợ scheme này)
    if (!scheme || scheme === "auto") {
      await chrome.storage.local.set({ status: "đang dò giao thức (local, http/socks5/https)..." });
      let probe = new ProxyProbe(cfg.ip, cfg.port);
      let detected = await probe.detectScheme();
      detectLog = detectLog.concat(detected.log);
      detectedNeedsAuth = detected.needsAuth;

      if (!detected.scheme) {
        await chrome.storage.local.set({ status: "không dò được giao thức phù hợp" });
        return { success: false, reason: "scheme_not_found", log: detectLog };
      }
      scheme = detected.scheme;
    }
  }

  await chrome.storage.local.set({ status: "đang kích hoạt...", scheme });

  // chốt sổ phiên kết nối TRƯỚC đó (nếu có) trước khi set config mới — quan
  // trọng cho trường hợp user bấm Kết Nối lại (đổi proxy khác) mà chưa bấm
  // Ngắt trước, nếu không phiên cũ sẽ bị tính thời gian chồng lên phiên mới
  await stopConnectionTimer();

  let connector = new ProxyConnect(cfg.ip, cfg.port, cfg.domains || [], cfg.ruleMode || "blacklist", scheme);
  await connector.connect();
  resetRotationHistory();

  // verify LUÔN làm local (qua chính kết nối vừa set trên máy mình) — đây là
  // tín hiệu DUY NHẤT xác nhận đúng máy MÌNH dùng được proxy này. mkvn chỉ
  // test được từ mạng của họ, có thể khác mạng mình (proxy giới hạn theo IP,
  // chặn vùng...) nên không dùng để quyết định thành/bại ở bước này, chỉ mượn
  // IP thật của nó (nếu có từ lúc dò scheme) để hiển thị cho đẹp
  let verify = await verifyProxyFromBackground();

  if (verify.success) {
    startHealthCheck();
    await startConnectionTimer();
    await applyLeakProtection();
    let displayIp = apiExitIp || verify.ip;
    let statusText = `${displayIp} - Proxy working (${scheme.toUpperCase()})`;
    await chrome.storage.local.set({ scheme, status: statusText, lastKnownIp: displayIp });
    return { success: true, scheme, ip: displayIp, log: detectLog };
  }

  let settings = await chrome.storage.local.get(["dontOffIfFailed"]);
  // dò thấy đúng scheme nhưng verify vẫn fail => gần như chắc chắn do sai/thiếu user-pass,
  // báo rõ thay vì để status chung chung "lỗi kết nối" gây hiểu nhầm là sai giao thức
  let failStatus = detectedNeedsAuth
    ? `giao thức ${scheme.toUpperCase()} đúng, nhưng sai hoặc thiếu user/pass`
    : "lỗi kết nối / không hoạt động";

  if (!settings.dontOffIfFailed) {
    let disconnector = new ProxyConnect("", 0);
    await disconnector.disconnect();
    await restoreLeakProtection();
    await chrome.storage.local.set({ status: failStatus });
  } else {
    await chrome.storage.local.set({ status: `${failStatus} (đang giữ cấu hình)` });
  }
  return { success: false, reason: "verify_failed", scheme, needsAuth: detectedNeedsAuth, log: detectLog };
}

// verify độc lập trong background thay vì popup, cùng lý do nêu trên
async function verifyProxyFromBackground() {
  try {
    let controller = new AbortController();
    let timeoutId = setTimeout(() => controller.abort(), 6000);
    let res = await fetch("https://api.ipify.org?format=json", { signal: controller.signal });
    clearTimeout(timeoutId);
    let data = await res.json();
    if (data && data.ip) return { success: true, ip: data.ip };
    return { success: false };
  } catch (error) {
    return { success: false };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "connectProxy") {
    let connector = new ProxyConnect(message.ip, message.port, message.domains, message.ruleMode, message.scheme);
    connector.connect().then(() => {
      resetRotationHistory();
      startHealthCheck();
      sendResponse({ success: true });
    });
    return true; // giữ kênh async mở
  }

  // luồng chính dùng cho nút "Kết Nối" và widget nổi trên trang — tự dò
  // scheme nếu cần, connect, verify, và cập nhật status; TẤT CẢ chạy trong
  // background nên không bị gãy nếu popup đóng giữa chừng
  if (message.action === "connectAndVerify") {
    connectAndVerify(message).then((result) => sendResponse(result));
    return true;
  }

  if (message.action === "detectScheme") {
    let probe = new ProxyProbe(message.ip, message.port);
    probe.detectScheme().then((result) => sendResponse(result));
    return true;
  }

  if (message.action === "measureProxyLatency") {
    let probe = new ProxyProbe(message.ip, message.port);
    probe.measureLatency(message.scheme).then((result) => sendResponse(result));
    return true;
  }

  if (message.action === "runProxyRating") {
    let rater = new ProxyRater(message.ip, message.port, message.scheme);
    rater.runAll().then((result) => sendResponse(result));
    return true;
  }

  if (message.action === "disconnectProxy") {
    let connector = new ProxyConnect("", 0);
    Promise.all([connector.disconnect(), stopConnectionTimer(), restoreLeakProtection()]).then(() => {
      stopHealthCheck();
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.action === "checkDelayChanged") {
    // người dùng đổi delay khi proxy đang chạy => restart alarm với chu kỳ mới
    chrome.storage.local.get(["status"], (data) => {
      if (data.status && data.status.includes("Proxy working")) {
        startHealthCheck();
      }
    });
  }

  if (message.action === "resetDataUsage") {
    chrome.storage.local.set({ dataUsedBytes: 0 }, () => sendResponse({ success: true }));
    return true;
  }

  if (message.action === "getUsageStats") {
    (async () => {
      // đang kết nối thì chốt sổ thời gian trước khi đọc, để số liệu hiện lên
      // popup luôn mới nhất chứ không phải tính tới lần health-check gần nhất
      let statusData = await chrome.storage.local.get(["status"]);
      if (statusData.status && statusData.status.includes("Proxy working")) {
        await flushConnectionTime();
      }
      let data = await chrome.storage.local.get(["dataUsedByDay", "connectTimeByDay", "dataUsedBytes"]);
      sendResponse({
        dataSeries: buildLastNDaysSeries(data.dataUsedByDay, CHART_DAYS),
        timeSeries: buildLastNDaysSeries(data.connectTimeByDay, CHART_DAYS),
        dataUsedBytes: data.dataUsedBytes || 0
      });
    })();
    return true;
  }
});

// kiểm tra proxy còn sống + phát hiện IP đổi (proxy xoay)
async function checkProxyHealth() {
  let data = await chrome.storage.local.get([
    "status", "lastKnownIp", "showNotifications",
    "autoDisconnectError", "autoDisconnectRotate", "scheme",
    "ip", "port", "user", "pass"
  ]);

  if (!data.status || !data.status.includes("Proxy working")) return;

  // đang kết nối thì luôn cộng dồn thời gian vào "hôm nay" mỗi lần health
  // check chạy — nhờ vậy biểu đồ thời gian kết nối luôn cập nhật gần thời
  // gian thực, không phải đợi tới lúc ngắt mới thấy số liệu
  await flushConnectionTime();

  let scheme = data.scheme || "http";
  let schemeSuffix = data.scheme ? ` (${data.scheme.toUpperCase()})` : "";
  // mkvn không có field auth — proxy có user/pass thì gửi qua đó sẽ luôn bị
  // báo DIE oan (server họ không tự đăng nhập được), nên có auth là bỏ qua
  // mkvn hoàn toàn, dùng thẳng cách cũ (ipify local, vốn tự support auth qua
  // onAuthRequired ở trên)
  let hasAuth = !!(data.user || data.pass);
  let canUseMkvn = !hasAuth && MkvnChecker.SUPPORTED_SCHEMES.includes(scheme);

  let currentIp = null;
  let usedMkvn = false;

  if (canUseMkvn) {
    let proxyResult = await MkvnChecker.checkProxy(data.ip, data.port, scheme);
    if (proxyResult.success && proxyResult.live) {
      usedMkvn = true;
      currentIp = proxyResult.exitIp;
    }
    // mkvn báo DIE hoặc tự lỗi/không phản hồi -> KHÔNG vội kết luận chết, để
    // check local bên dưới quyết định. mkvn test từ mạng của họ, có thể khác
    // mạng mình (proxy giới hạn theo IP, chặn vùng...) — DIE từ họ không chắc
    // nghĩa là mình cũng không dùng được, disconnect oan sẽ rất khó chịu
  }

  if (!currentIp) {
    let fallback = await checkAliveViaIpify();
    if (!fallback) {
      await handleHealthCheckFailure(data);
      return;
    }
    currentIp = fallback;
  }

  // IP đổi so với lần trước => proxy đã xoay IP
  if (data.lastKnownIp && data.lastKnownIp !== currentIp) {
    await recordRotation();

    if (data.showNotifications !== false) {
      notify("Proxy đã đổi IP", `IP mới: ${currentIp}`);
    }
    broadcastToTabs("ipRotated", { newIp: currentIp });

    if (data.autoDisconnectRotate) {
      let connector = new ProxyConnect("", 0);
      await connector.disconnect();
      await stopConnectionTimer();
      await restoreLeakProtection();
      stopHealthCheck();
      chrome.storage.local.set({ status: "chưa kết nối (đã tự ngắt do đổi IP)" });
      return;
    }
  }

  // số ping thật hiện trên widget nổi — trước đây field này bị hardcode "ok",
  // không phản ánh gì cả. Chỉ gọi thêm khi đã dùng được mkvn ở trên (tránh
  // tốn thêm 1 request vô ích nếu đang chạy fallback ipify vì có auth)
  let pingDisplay = "--";
  if (usedMkvn) {
    let pingResult = await MkvnChecker.checkPing(data.ip, data.port, scheme);
    if (pingResult.success) {
      pingDisplay = pingResult.alive ? (MkvnChecker.extractPingMs(pingResult.output) || "OK") : "FAIL";
    }
  }

  chrome.storage.local.set({
    lastKnownIp: currentIp,
    status: `${currentIp} - Proxy working${schemeSuffix}`,
    currentPing: pingDisplay
  });
}

async function handleHealthCheckFailure(data) {
  if (data.showNotifications !== false) {
    notify("Mất kết nối Proxy", "Proxy hiện không phản hồi, vui lòng kiểm tra lại.");
  }
  broadcastToTabs("showError", { message: "proxy mất kết nối" });

  if (data.autoDisconnectError) {
    let connector = new ProxyConnect("", 0);
    await connector.disconnect();
    await stopConnectionTimer();
    await restoreLeakProtection();
    stopHealthCheck();
    chrome.storage.local.set({ status: "lỗi kết nối / không hoạt động" });
  }
}

// cách cũ, giữ lại làm fallback khi mkvn không dùng được (có auth, hoặc mkvn
// tự nó lỗi/không phản hồi) — vẫn phải có đường lùi để không phụ thuộc hoàn
// toàn vào 1 API bên thứ 3 có thể đổi/sập bất cứ lúc nào
async function checkAliveViaIpify() {
  try {
    let controller = new AbortController();
    let timeoutId = setTimeout(() => controller.abort(), 6000);
    let res = await fetch("https://api.ipify.org?format=json", { signal: controller.signal });
    clearTimeout(timeoutId);
    let json = await res.json();
    return json && json.ip ? json.ip : null;
  } catch (error) {
    return null;
  }
}

// lưu lại mốc thời gian mỗi lần phát hiện đổi IP, dùng để ước tính chu kỳ xoay
async function recordRotation() {
  let now = Date.now();
  let data = await chrome.storage.local.get(["rotateHistory"]);
  let history = Array.isArray(data.rotateHistory) ? data.rotateHistory : [];
  history.push(now);
  if (history.length > MAX_ROTATE_HISTORY) {
    history = history.slice(history.length - MAX_ROTATE_HISTORY);
  }
  chrome.storage.local.set({ rotateHistory: history, lastRotateAt: now });
}

// xóa lịch sử xoay IP khi kết nối proxy mới (proxy khác thì lịch sử cũ không còn ý nghĩa)
function resetRotationHistory() {
  chrome.storage.local.set({ rotateHistory: [], lastRotateAt: null });
}

const NOTIF_ICON = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAACXBIWXMAAAsTAAALEwEAmpwYAAABK0lEQVR4nO3aMU7DQBCF4T8SqSm4AhIdEhwgN6DhFhwhV6DlBrTcgAYJcQOgQ0iRIiEqGjqCGhWWLI3GY3vX9pJi+aWnaN/svJnZjWMkSZIkSb1zBOwDD8AJ8AXMKn9OtCPgFHgHFq3vC7ADHNdKvA4c6vP2WVIzcRZ4WZP4t0MnwHYNBK6X4vwB1zXCn6XxfwPXwFFF/nHiT4fkGeAJmA6cP1eczoBpJcccOF+xkPMh+VeCbwXCf8mtRWt4b0EMuMuMYUmy1qFRWrqm3uKG1vRe/GmzWo5r3rN1Q+3AeSb/rbSm2z2m6/UfF4E1rWljz4gvJVL/xhh4TVzYW2LNlIwzUnwGdgvbxDlwXvlxK4qijjkH7hI3aSnJfSzGwCVFXye5UGdJkiRJUnO+AbAlIcVn6PC4AAAAAElFTkSuQmCC";

function notify(title, message) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: NOTIF_ICON,
    title: title,
    message: message
  }, () => {
    if (chrome.runtime.lastError) {
      console.log("notify lỗi:", chrome.runtime.lastError.message);
    }
  });
}

function broadcastToTabs(action, extra = {}) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      chrome.tabs.sendMessage(tab.id, { action, ...extra }, () => {
        if (chrome.runtime.lastError) {
          // tab không có content script, bỏ qua
        }
      });
    });
  });
}

// dùng chrome.alarms để chạy định kỳ, vì setTimeout sẽ chết khi service worker
// bị chrome tắt đi lúc idle. alarms bị giới hạn tối thiểu 1 phút/lần (chính sách chrome),
// nên checkDelaySec dưới 60 sẽ tự động làm tròn lên 1 phút.
function startHealthCheck() {
  chrome.storage.local.get(["checkDelaySec"], (data) => {
    let delaySec = data.checkDelaySec || DEFAULT_CHECK_DELAY_SEC;
    let periodInMinutes = Math.max(1, delaySec / 60);
    chrome.alarms.create(CHECK_ALARM, { periodInMinutes });
  });
}

function stopHealthCheck() {
  chrome.alarms.clear(CHECK_ALARM);
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === CHECK_ALARM) {
    checkProxyHealth();
  }
});

// nếu service worker restart giữa chừng mà proxy đang chạy, resume health check
chrome.storage.local.get(["status"], (data) => {
  if (data.status && data.status.includes("Proxy working")) {
    startHealthCheck();
  }
});
