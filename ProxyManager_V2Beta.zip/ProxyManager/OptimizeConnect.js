if (!globalThis.OptimizeConnect) {
  globalThis.OptimizeConnect = class OptimizeConnect {
    // bản cũ đo độ trễ bằng cách ping thẳng tới ip-api.com — không hề đi qua
    // proxy đang test, nên số hiển thị không phản ánh đúng chất lượng proxy.
    // Giờ nhờ background áp cấu hình proxy tạm thời rồi đo độ trễ THẬT qua
    // đúng đường đó (xem ProxyProbe.measureLatency).
    constructor(ip, port, scheme = "auto") {
      this.ip = ip;
      this.port = port;
      this.scheme = scheme || "auto";
    }

    async checkLatency() {
      let effectiveScheme = this.scheme;

      if (effectiveScheme === "auto") {
        let detected = await this._sendMessage({ action: "detectScheme", ip: this.ip, port: this.port });
        if (!detected || !detected.scheme) return "không xác định được giao thức";
        effectiveScheme = detected.scheme;
      }

      let result = await this._sendMessage({
        action: "measureProxyLatency", ip: this.ip, port: this.port, scheme: effectiveScheme
      });

      if (!result || !result.success) return "hết hạn / lỗi";
      return `${result.latencyMs} ms (${effectiveScheme.toUpperCase()})`;
    }

    _sendMessage(message) {
      return new Promise((resolve) => {
        chrome.runtime.sendMessage(message, (response) => resolve(response));
      });
    }

    getOptimizationAdvice(latencyStr) {
      if (latencyStr.includes("hết hạn") || latencyStr.includes("lỗi") || latencyStr.includes("không xác định")) {
        return "kết nối hỏng, vui lòng không sử dụng";
      }
      let latencyVal = parseInt(latencyStr);
      if (latencyVal < 150) return "tốc độ tối ưu, cực kỳ mượt mà";
      if (latencyVal < 350) return "tốc độ ổn định, sử dụng tốt";
      if (latencyVal < 600) return "tốc độ trung bình, hơi chậm";
      return "tốc độ rất kém, khuyên dùng proxy khác";
    }
  };
}
