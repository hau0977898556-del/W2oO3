// ProxyRater: chấm điểm/chẩn đoán proxy hiện tại — kiểu ipleak.net,
// browserleaks.com nhưng chạy ngay trong extension. Chỉ BÁO CÁO tình trạng
// thật (có lộ header không, có lộ IPv6 không, múi giờ có khớp không...),
// không tự sửa/giả mạo bất kỳ thứ gì — khác hẳn "anti-detect", đây thuần là
// công cụ chẩn đoán để người dùng tự biết proxy mình đang dùng có vấn đề gì.
//
// Chạy trong background vì cần snapshot/apply/restore chrome.proxy.settings
// giống ProxyProbe — không load vào popup.
if (!globalThis.ProxyRater) {
  globalThis.ProxyRater = class ProxyRater {
    static HEADERS_ECHO_URL = "https://httpbin.org/headers";
    static TOR_CHECK_URL = "https://check.torproject.org/api/ip";
    static IPV6_CHECK_URL = "https://api6.ipify.org?format=json";
    static LATENCY_CHECK_URL = "https://api.ipify.org?format=json";
    static TIMEOUT_MS = 8000;
    static SETTLE_DELAY_MS = 250;

    // các header mà proxy "rẻ tiền"/thiếu ẩn danh hay tự thêm vào, tố cáo
    // ngay lập tức là request đang đi qua 1 proxy trung gian
    static SUSPICIOUS_HEADER_PATTERN = /^(x-forwarded-for|via|forwarded|x-real-ip|proxy-connection|x-proxy)/i;

    constructor(ip, port, scheme) {
      this.ip = (ip || "").trim();
      this.port = parseInt(port);
      this.scheme = scheme || "http";
    }

    static sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }

    // chạy toàn bộ các check song song, tự set/khôi phục cấu hình proxy tạm
    // thời để đảm bảo test đi ĐÚNG qua proxy đang được đánh giá
    async runAll() {
      let snapshot = await this._snapshotConfig();
      let applied = await this._applyTempConfig();
      if (!applied) {
        return { error: "không áp dụng được cấu hình proxy để test" };
      }

      try {
        await ProxyRater.sleep(ProxyRater.SETTLE_DELAY_MS);

        let [headers, tor, timezone, ipv6, latency] = await Promise.all([
          this._checkHeaders(),
          this._checkTor(),
          this._checkTimezone(),
          this._checkIpv6Leak(),
          this._measureLatency()
        ]);

        return { headers, tor, timezone, ipv6, latency };
      } finally {
        await this._restoreConfig(snapshot);
      }
    }

    // ================= từng check =================

    async _checkHeaders() {
      try {
        let res = await this._fetchWithTimeout(ProxyRater.HEADERS_ECHO_URL);
        let data = await res.json();
        let headers = (data && data.headers) || {};
        let suspicious = Object.keys(headers).filter((k) => ProxyRater.SUSPICIOUS_HEADER_PATTERN.test(k));

        if (suspicious.length > 0) {
          return { status: "leak", detail: `header lộ proxy: ${suspicious.join(", ")}` };
        }
        return { status: "clean", detail: "không thấy header tố cáo proxy" };
      } catch (error) {
        return { status: "unknown", detail: "không kiểm tra được (lỗi mạng)" };
      }
    }

    async _checkTor() {
      try {
        let res = await this._fetchWithTimeout(ProxyRater.TOR_CHECK_URL);
        let data = await res.json();
        if (data && data.IsTor) {
          return { status: "leak", detail: "IP nằm trong danh sách exit node Tor" };
        }
        return { status: "clean", detail: "không phải Tor exit node" };
      } catch (error) {
        return { status: "unknown", detail: "không kiểm tra được (lỗi mạng)" };
      }
    }

    // so múi giờ hệ thống với múi giờ theo geolocation của IP proxy — chỉ báo
    // lệch, không tự động sửa gì cả
    async _checkTimezone() {
      try {
        let res = await this._fetchWithTimeout(`https://ip-api.com/json/${this.ip}`);
        let data = await res.json();
        let proxyTz = data && data.timezone;
        let localTz = Intl.DateTimeFormat().resolvedOptions().timeZone;

        if (!proxyTz) return { status: "unknown", detail: "không lấy được múi giờ của proxy" };
        if (proxyTz === localTz) return { status: "clean", detail: `khớp (${localTz})` };
        return { status: "warn", detail: `lệch múi giờ — máy: ${localTz}, proxy: ${proxyTz}` };
      } catch (error) {
        return { status: "unknown", detail: "không kiểm tra được (lỗi mạng)" };
      }
    }

    async _checkIpv6Leak() {
      try {
        let res = await this._fetchWithTimeout(ProxyRater.IPV6_CHECK_URL, 4000);
        let data = await res.json();
        if (data && data.ip) {
          return { status: "leak", detail: `lộ địa chỉ IPv6 thật: ${data.ip}` };
        }
        return { status: "clean", detail: "không lộ IPv6" };
      } catch (error) {
        // KHÔNG kết nối được tới endpoint IPv6-only chính là kết quả TỐT ở
        // đây — nghĩa là không có đường IPv6 trực tiếp nào để rò rỉ ra ngoài
        return { status: "clean", detail: "không có đường IPv6 trực tiếp (an toàn)" };
      }
    }

    async _measureLatency() {
      try {
        let startedAt = Date.now();
        await this._fetchWithTimeout(ProxyRater.LATENCY_CHECK_URL);
        let ms = Date.now() - startedAt;
        let status = ms < 300 ? "clean" : ms < 800 ? "warn" : "leak";
        return { status, detail: `${ms}ms` };
      } catch (error) {
        return { status: "unknown", detail: "không đo được (lỗi mạng)" };
      }
    }

    // ================= helpers =================

    async _fetchWithTimeout(url, timeoutMs) {
      let controller = new AbortController();
      let timeoutId = setTimeout(() => controller.abort(), timeoutMs || ProxyRater.TIMEOUT_MS);
      try {
        let res = await fetch(url, { signal: controller.signal, cache: "no-store" });
        clearTimeout(timeoutId);
        return res;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    }

    _snapshotConfig() {
      return new Promise((resolve) => {
        chrome.proxy.settings.get({}, (details) => resolve(details.value));
      });
    }

    _restoreConfig(snapshotValue) {
      return new Promise((resolve) => {
        chrome.proxy.settings.set({ value: snapshotValue, scope: "regular" }, () => resolve());
      });
    }

    _applyTempConfig() {
      return new Promise((resolve) => {
        let config = {
          mode: "fixed_servers",
          rules: {
            singleProxy: { scheme: this.scheme, host: this.ip, port: this.port },
            bypassList: ["localhost", "127.0.0.1"]
          }
        };
        chrome.proxy.settings.set({ value: config, scope: "regular" }, () => {
          resolve(!chrome.runtime.lastError);
        });
      });
    }
  };
}
