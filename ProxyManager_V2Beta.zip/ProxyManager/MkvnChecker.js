// MkvnChecker: gọi API của proxy.mkvn.net (tự dò được qua userscript sniffer)
// để kiểm tra proxy sống/chết + ping THẬT từ server họ, không cần đụng tới
// chrome.proxy.settings của máy mình — nhanh hơn và không làm gián đoạn proxy
// đang kết nối (nếu có) như cách dò local (ProxyProbe) phải làm.
//
// LƯU Ý QUAN TRỌNG: đây là API không công khai/không có doc chính thức, dò
// được qua request thực tế nên định dạng field có thể không chính xác 100%
// (đặc biệt là checkPing — field "proxy" chưa rõ format chuẩn). Mọi chỗ gọi
// API này đều có try/catch trả về success:false khi lỗi, để chỗ gọi luôn có
// đường lùi (fallback) về cách kiểm tra local cũ, không phụ thuộc hoàn toàn
// vào 1 API bên thứ 3 có thể đổi/sập bất cứ lúc nào.
//
// KHÔNG bao giờ gửi user/pass của proxy qua API này — field API không hỗ trợ
// auth (không thấy trong request mẫu), gửi ip:port của proxy có auth qua đây
// sẽ luôn bị báo DIE oan vì server họ không tự đăng nhập được. Chỗ gọi cần tự
// kiểm tra "có auth không" TRƯỚC khi quyết định dùng MkvnChecker hay không.
if (!globalThis.MkvnChecker) {
  globalThis.MkvnChecker = class MkvnChecker {
    static BASE_URL = "https://proxy.mkvn.net";
    static CHECK_PROXY_PATH = "/core/checkproxy/Checkproxy";
    static CHECK_PING_PATH = "/core/checkping/checkping-core";
    static TIMEOUT_MS = 8000;

    // API chỉ nhận 2 giá trị này cho selected_proxy — không có "https" riêng,
    // khớp với thực tế: "https proxy" đa số chỉ là http proxy tunnel https
    // qua CONNECT, trường hợp tự nói TLS thẳng tới proxy rất hiếm gặp
    static SUPPORTED_SCHEMES = ["http", "socks5"];

    // kiểm tra 1 proxy còn sống hay không qua server mkvn + lấy IP thật nếu sống
    static async checkProxy(ip, port, scheme) {
      let body = new URLSearchParams();
      body.set("ip_proxy", `${ip}:${port}`);
      body.set("selected_proxy", scheme);

      try {
        let controller = new AbortController();
        let timeoutId = setTimeout(() => controller.abort(), MkvnChecker.TIMEOUT_MS);
        let res = await fetch(MkvnChecker.BASE_URL + MkvnChecker.CHECK_PROXY_PATH, {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: body.toString(),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        let data = await res.json();

        if (data && data.status === "LIVE") {
          return { success: true, live: true, exitIp: data.ip, responseTime: data.response_time };
        }
        return { success: true, live: false, responseTime: data && data.response_time };
      } catch (error) {
        // gọi API lỗi (mất mạng tới mkvn, site sập, đổi format...) KHÔNG có
        // nghĩa proxy chết — chỉ là không kiểm tra được qua đường này, để chỗ
        // gọi tự quyết định fallback, không vội kết luận DIE
        return { success: false, error: error.message };
      }
    }

    // đo ping thật qua proxy (server mkvn tự ping hộ tới google.com)
    static async checkPing(ip, port, scheme) {
      let form = new FormData();
      // ĐOÁN theo mẫu curl Hau cung cấp, chưa chắc chắn 100% format field
      // "proxy" đúng cú pháp mkvn cần — nếu API trả lỗi liên tục ở đây, mở lại
      // userscript sniffer bắt request thật để chỉnh lại chỗ này
      form.set("proxy", `${scheme}:${ip}:${port}`);
      form.set("index", String(Date.now()));

      try {
        let controller = new AbortController();
        let timeoutId = setTimeout(() => controller.abort(), MkvnChecker.TIMEOUT_MS);
        let res = await fetch(MkvnChecker.BASE_URL + MkvnChecker.CHECK_PING_PATH, {
          method: "POST",
          body: form,
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        let data = await res.json();
        return { success: true, alive: !!data.success, output: data.output };
      } catch (error) {
        return { success: false, error: error.message };
      }
    }

    // rút số ms từ chuỗi output kiểu "...seq=0 time=123.45" để hiện gọn trên UI
    static extractPingMs(output) {
      if (!output) return null;
      let match = /time=([\d.]+)/.exec(output);
      return match ? `${match[1]}ms` : null;
    }

    // thử http rồi socks5 qua mkvn — nhanh hơn nhiều so với dò local vì không
    // phải đổi chrome.proxy.settings mỗi lần thử. Trả scheme=null nếu cả 2
    // đều DIE (chỗ gọi tự quyết định fallback sang ProxyProbe local)
    static async detectSchemeViaApi(ip, port) {
      for (let scheme of MkvnChecker.SUPPORTED_SCHEMES) {
        let result = await MkvnChecker.checkProxy(ip, port, scheme);
        if (!result.success) return { scheme: null, apiUnavailable: true };
        if (result.live) return { scheme, exitIp: result.exitIp };
      }
      return { scheme: null, apiUnavailable: false };
    }
  };
}
