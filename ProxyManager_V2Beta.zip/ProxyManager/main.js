// dùng query string tường minh để biết đang ở "chế độ đầy đủ" (mở qua tab riêng)
// hay đang là popup thật, vì chrome.runtime.id vẫn tồn tại ở cả 2 trường hợp.
// (trước đây đây là 1 <script> inline trong main.html, bị CSP mặc định của
// MV3 chặn — script-src 'self' không cho phép unsafe-inline dù có sửa manifest,
// nên phải dời hẳn vào file .js này)
(function () {
  let params = new URLSearchParams(window.location.search);
  if (params.get("fullui") === "1") {
    document.body.classList.add("is-mobile-view");
  }
})();

document.addEventListener("DOMContentLoaded", () => {
  let bulkInput = document.getElementById("bulkInput");
  let ipInput = document.getElementById("ipInput");
  let portInput = document.getElementById("portInput");
  let userInput = document.getElementById("userInput");
  let passInput = document.getElementById("passInput");
  let ruleModeSelect = document.getElementById("ruleMode");
  let schemeSelect = document.getElementById("schemeSelect");
  let domainsInput = document.getElementById("domainsInput"); // textarea ẩn, giữ chuỗi domains gốc

  let domainList = document.getElementById("domainList");
  let domainNewInput = document.getElementById("domainNewInput");
  let btnAddDomain = document.getElementById("btnAddDomain");
  let domainSaveHint = document.getElementById("domainSaveHint");

  let chkWebrtcProtection = document.getElementById("chkWebrtcProtection");
  let chkAutoDisconnectError = document.getElementById("chkAutoDisconnectError");
  let chkAutoDisconnectRotate = document.getElementById("chkAutoDisconnectRotate");
  let chkShowNotifications = document.getElementById("chkShowNotifications");
  let chkDontOffIfFailed = document.getElementById("chkDontOffIfFailed");
  let checkDelayInput = document.getElementById("checkDelayInput");
  let txtDataUsed = document.getElementById("txtDataUsed");
  let btnResetData = document.getElementById("btnResetData");
  let btnFullUi = document.getElementById("btnFullUi");

  let btnCheck = document.getElementById("btnCheck");
  let btnOptimize = document.getElementById("btnOptimize");
  let btnConnect = document.getElementById("btnConnect");
  let btnDisconnect = document.getElementById("btnDisconnect");

  let txtCountry = document.getElementById("txtCountry");
  let txtCity = document.getElementById("txtCity");
  let txtIsp = document.getElementById("txtIsp");
  let txtTimezone = document.getElementById("txtTimezone");
  let txtLatency = document.getElementById("txtLatency");
  let txtAdvice = document.getElementById("txtAdvice");
  let txtStatus = document.getElementById("txtStatus");
  let statusLine = document.getElementById("statusLine");
  let txtRotateEstimate = document.getElementById("txtRotateEstimate");

  let detectLogWrap = document.getElementById("detectLogWrap");
  let detectLogBody = document.getElementById("detectLogBody");
  let btnToggleDetectLog = document.getElementById("btnToggleDetectLog");

  let dataChartContainer = document.getElementById("dataChartContainer");
  let timeChartContainer = document.getElementById("timeChartContainer");
  let txtDataChartTotal = document.getElementById("txtDataChartTotal");
  let txtTimeChartTotal = document.getElementById("txtTimeChartTotal");

  let btnRateProxy = document.getElementById("btnRateProxy");
  let rateSummary = document.getElementById("rateSummary");
  let rateList = document.getElementById("rateList");

  const MIN_DELAY_SEC = 15;
  // chỉ cho phép ký tự hợp lệ của domain + dấu "*" để làm wildcard (vd *.google.com)
  const DOMAIN_PATTERN = /^\*?[a-zA-Z0-9]([a-zA-Z0-9-]{0,62}\.)*\*?[a-zA-Z0-9-]{1,63}(\.[a-zA-Z]{2,})?$|^\*\.[a-zA-Z0-9-]+(\.[a-zA-Z]{2,})+$/;

  let domains = []; // mảng domain hiện tại, nguồn sự thật cho UI danh sách
  let rotateEstimateTimer = null;

  // dọn ip nếu user lỡ dán nguyên chuỗi "http://1.2.3.4/" từ 1 list proxy nào
  // đó — trước đây không có bước này nên connect/detect âm thầm sai địa chỉ
  // mà không báo lỗi rõ ràng gì cả
  function sanitizeIpInput(raw) {
    return (raw || "").trim().replace(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//, "").replace(/\/+$/, "");
  }

  // load lại cấu hình đã lưu khi mở popup
  chrome.storage.local.get([
    "ip", "port", "user", "pass", "status", "ruleMode", "domains", "scheme",
    "autoDisconnectError", "autoDisconnectRotate", "showNotifications",
    "dontOffIfFailed", "checkDelaySec", "dataUsedBytes", "webrtcProtection",
    "rotateHistory", "lastRotateAt"
  ], (data) => {
    if (data.ip) ipInput.value = data.ip;
    if (data.port) portInput.value = data.port;
    if (data.user) userInput.value = data.user;
    if (data.pass) passInput.value = data.pass;
    if (data.ruleMode) ruleModeSelect.value = data.ruleMode;
    if (data.scheme) schemeSelect.value = data.scheme;

    domains = parseDomainsString(data.domains || "");
    renderDomainList();

    chkWebrtcProtection.checked = data.webrtcProtection !== false;
    chkAutoDisconnectError.checked = data.autoDisconnectError !== false;
    chkAutoDisconnectRotate.checked = data.autoDisconnectRotate !== false;
    chkShowNotifications.checked = data.showNotifications !== false;
    chkDontOffIfFailed.checked = data.dontOffIfFailed === true;
    checkDelayInput.value = data.checkDelaySec || 30;
    txtDataUsed.innerText = formatBytes(data.dataUsedBytes || 0);

    renderStatus(data.status || "chưa kết nối");
    renderRotateEstimate(data.rotateHistory, data.lastRotateAt);
    startRotateEstimateTicker();
    loadUsageStats();
  });

  // ==== Domain list: parse / render / thao tác ====

  function parseDomainsString(raw) {
    return raw.split(",").map(d => d.trim()).filter(d => d);
  }

  function domainsToString() {
    return domains.join(", ");
  }

  function isValidDomain(value) {
    if (!value) return false;
    return DOMAIN_PATTERN.test(value);
  }

  function renderDomainList() {
    domainList.innerHTML = "";
    domains.forEach((domain, index) => {
      let item = document.createElement("div");
      item.className = "domain-item";

      let input = document.createElement("input");
      input.type = "text";
      input.value = domain;
      input.spellcheck = false;
      input.dataset.index = String(index);

      // auto-save ngay khi input này mất focus, không cần bấm nút lưu riêng
      input.addEventListener("blur", () => {
        commitDomainEdit(index, input.value.trim());
      });
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") input.blur();
      });

      let removeBtn = document.createElement("button");
      removeBtn.type = "button";
      removeBtn.className = "domain-item-remove";
      removeBtn.innerText = "✕";
      removeBtn.addEventListener("click", () => {
        domains.splice(index, 1);
        renderDomainList();
        saveDomains();
      });

      item.appendChild(input);
      item.appendChild(removeBtn);
      domainList.appendChild(item);
    });
  }

  function commitDomainEdit(index, newValue) {
    if (!newValue) {
      domains.splice(index, 1);
      renderDomainList();
      saveDomains();
      return;
    }
    domains[index] = newValue;
    saveDomains();
    // đánh dấu ô hợp lệ hay không, chỉ mang tính gợi ý trực quan (không chặn lưu)
    let itemEl = domainList.children[index];
    if (itemEl) itemEl.classList.toggle("invalid", !isValidDomain(newValue));
  }

  function addDomainFromInput() {
    let value = domainNewInput.value.trim();
    if (!value) return;
    domains.push(value);
    domainNewInput.value = "";
    renderDomainList();
    saveDomains();
  }

  btnAddDomain.addEventListener("click", addDomainFromInput);
  domainNewInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addDomainFromInput();
    }
  });
  // mất focus khỏi ô nhập domain mới mà còn nội dung thì cũng tự thêm luôn,
  // đúng tinh thần "mất focus là auto save"
  domainNewInput.addEventListener("blur", () => {
    if (domainNewInput.value.trim()) addDomainFromInput();
  });

  function saveDomains() {
    let rawDomains = domainsToString();
    domainsInput.value = rawDomains;
    chrome.storage.local.set({ domains: rawDomains }, () => {
      flashSaveHint();
    });
  }

  let saveHintTimer = null;
  function flashSaveHint() {
    domainSaveHint.classList.add("show");
    clearTimeout(saveHintTimer);
    saveHintTimer = setTimeout(() => domainSaveHint.classList.remove("show"), 1400);
  }

  // ==== Ước tính chu kỳ xoay IP ====

  function renderRotateEstimate(rotateHistory, lastRotateAt) {
    let estimator = new RotationEstimator(rotateHistory, lastRotateAt);
    txtRotateEstimate.innerText = estimator.getEstimateText();
  }

  function startRotateEstimateTicker() {
    if (rotateEstimateTimer) clearInterval(rotateEstimateTimer);
    // cập nhật đếm ngược mỗi giây trong khi popup đang mở
    rotateEstimateTimer = setInterval(() => {
      chrome.storage.local.get(["rotateHistory", "lastRotateAt"], (data) => {
        renderRotateEstimate(data.rotateHistory, data.lastRotateAt);
      });
    }, 1000);
  }

  // ==== Biểu đồ thống kê dữ liệu đã dùng + thời gian kết nối (7 ngày) ====

  let loadStatsTimer = null;

  function loadUsageStats() {
    chrome.runtime.sendMessage({ action: "getUsageStats" }, (response) => {
      if (!response) return;
      renderDataChart(response.dataSeries || []);
      renderTimeChart(response.timeSeries || []);
    });
  }

  // gọi loadUsageStats nhiều lần liên tiếp trong thời gian ngắn (vd nhiều
  // request tải trang dồn dập) chỉ cần vẽ lại 1 lần cuối, đỡ giật biểu đồ
  function scheduleLoadUsageStats() {
    clearTimeout(loadStatsTimer);
    loadStatsTimer = setTimeout(loadUsageStats, 600);
  }

  // chọn 1 đơn vị byte chung cho toàn bộ chuỗi (dựa theo giá trị lớn nhất),
  // giống cách biểu đồ tham khảo dùng 1 đơn vị nhất quán cho cả trục lẫn từng
  // điểm, thay vì mỗi điểm tự đổi đơn vị gây khó so sánh
  function pickByteFormatter(maxBytes) {
    if (maxBytes >= 1024 * 1024 * 1024) {
      return (v) => `${(v / (1024 * 1024 * 1024)).toFixed(v >= 1024 * 1024 * 1024 * 10 ? 0 : 2)} GB`;
    }
    if (maxBytes >= 1024 * 1024) {
      return (v) => `${(v / (1024 * 1024)).toFixed(v >= 1024 * 1024 * 10 ? 0 : 1)} MB`;
    }
    return (v) => `${(v / 1024).toFixed(v >= 1024 * 10 ? 0 : 1)} KB`;
  }

  // tương tự nhưng cho thời gian kết nối (giây -> phút/giờ)
  function pickDurationFormatter(maxSeconds) {
    if (maxSeconds >= 3600) {
      return (v) => `${(v / 3600).toFixed(1)}h`;
    }
    return (v) => `${Math.round(v / 60)}m`;
  }

  function renderDataChart(series) {
    let maxVal = Math.max(0, ...series.map((p) => p.value));
    let formatter = pickByteFormatter(maxVal || 1);
    ChartRenderer.render(dataChartContainer, series, { formatValue: formatter });

    let total = series.reduce((sum, p) => sum + p.value, 0);
    txtDataChartTotal.innerText = formatBytes(total);
  }

  function renderTimeChart(series) {
    let maxVal = Math.max(0, ...series.map((p) => p.value));
    let formatter = pickDurationFormatter(maxVal || 1);
    ChartRenderer.render(timeChartContainer, series, { formatValue: formatter });

    let totalSec = series.reduce((sum, p) => sum + p.value, 0);
    txtTimeChartTotal.innerText = formatConnectDuration(totalSec);
  }

  // giây -> chuỗi "Xh Ym" hoặc "Ym" dễ đọc cho tổng thời gian kết nối
  function formatConnectDuration(totalSec) {
    if (!totalSec || totalSec <= 0) return "0 phút";
    let hours = Math.floor(totalSec / 3600);
    let minutes = Math.round((totalSec % 3600) / 60);
    if (hours > 0) return `${hours} giờ ${minutes} phút`;
    return `${minutes} phút`;
  }

  // đổi byte thô sang KB/MB/GB dễ đọc
  function formatBytes(bytes) {
    if (!bytes || bytes <= 0) return "0 KB";
    let kb = bytes / 1024;
    if (kb < 1024) return `${kb.toFixed(1)} KB`;
    let mb = kb / 1024;
    if (mb < 1024) return `${mb.toFixed(2)} MB`;
    let gb = mb / 1024;
    return `${gb.toFixed(2)} GB`;
  }

  function renderStatus(text) {
    txtStatus.innerText = text;
    statusLine.classList.remove("status-ok", "status-error", "status-progress", "status-idle");

    if (text.includes("Proxy working")) {
      statusLine.classList.add("status-ok");
    } else if (text.includes("lỗi") || text.includes("không hoạt động") || text.includes("sai") || text.includes("không dò được")) {
      statusLine.classList.add("status-error");
    } else if (text.includes("đang")) {
      statusLine.classList.add("status-progress");
    } else {
      statusLine.classList.add("status-idle");
    }
  }

  // hiển thị log chi tiết vì sao dò giao thức thành công/thất bại — thay vì
  // chỉ báo chung chung "không hoạt động" như bản cũ, giờ người dùng thấy
  // đúng mã lỗi net::ERR_* để tự phán đoán (sai port? sai scheme? do firewall?)
  function renderDetectLog(log) {
    if (!log || !log.length) {
      detectLogWrap.style.display = "none";
      detectLogBody.classList.remove("show");
      btnToggleDetectLog.innerText = "Xem log dò giao thức ▾";
      return;
    }
    detectLogBody.innerHTML = "";
    log.forEach((entry) => {
      let line = document.createElement("div");
      line.className = `log-line lvl-${entry.level}`;
      line.innerText = entry.text;
      detectLogBody.appendChild(line);
    });
    detectLogWrap.style.display = "block";
  }

  btnToggleDetectLog.addEventListener("click", () => {
    let showing = detectLogBody.classList.toggle("show");
    btnToggleDetectLog.innerText = showing ? "Ẩn log dò giao thức ▴" : "Xem log dò giao thức ▾";
  });

  chkWebrtcProtection.addEventListener("change", () => {
    chrome.storage.local.set({ webrtcProtection: chkWebrtcProtection.checked });
  });
  chkAutoDisconnectError.addEventListener("change", () => {
    chrome.storage.local.set({ autoDisconnectError: chkAutoDisconnectError.checked });
  });
  chkAutoDisconnectRotate.addEventListener("change", () => {
    chrome.storage.local.set({ autoDisconnectRotate: chkAutoDisconnectRotate.checked });
  });
  chkShowNotifications.addEventListener("change", () => {
    chrome.storage.local.set({ showNotifications: chkShowNotifications.checked });
  });
  chkDontOffIfFailed.addEventListener("change", () => {
    chrome.storage.local.set({ dontOffIfFailed: chkDontOffIfFailed.checked });
  });

  // đổi delay check, validate tối thiểu 15s rồi báo background restart alarm
  checkDelayInput.addEventListener("change", () => {
    let val = parseInt(checkDelayInput.value);
    if (isNaN(val) || val < MIN_DELAY_SEC) val = MIN_DELAY_SEC;
    checkDelayInput.value = val;
    chrome.storage.local.set({ checkDelaySec: val }, () => {
      chrome.runtime.sendMessage({ action: "checkDelayChanged" });
    });
  });

  btnResetData.addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "resetDataUsage" }, () => {
      txtDataUsed.innerText = formatBytes(0);
    });
  });

  // mở lại chính main.html nhưng ở tab riêng thay vì popup, tránh trường hợp
  // popup tự đóng khi mất focus (vd khi kéo cửa sổ, alt-tab) giữa lúc đang thao tác
  btnFullUi.addEventListener("click", () => {
    let fullUrl = chrome.runtime.getURL("main.html") + "?fullui=1";
    chrome.tabs.create({ url: fullUrl });
    window.close();
  });

  bulkInput.addEventListener("input", () => {
    let rawVal = bulkInput.value;
    if (!rawVal.trim()) return;
    let parsed = ProxyInformation.parseBulkProxy(rawVal);
    if (parsed) {
      ipInput.value = parsed.ip;
      portInput.value = parsed.port;
      userInput.value = parsed.user;
      passInput.value = parsed.pass;
    }
  });

  btnCheck.addEventListener("click", async () => {
    let ip = sanitizeIpInput(ipInput.value);
    ipInput.value = ip;
    let port = portInput.value.trim();
    let info = new ProxyInformation(ip, port);
    if (!info.checkDataAvailable()) return;

    setLoadingInfo();
    let details = await info.getDetailedInfo();
    if (details) {
      txtCountry.innerText = details.country;
      txtCity.innerText = details.city;
      txtIsp.innerText = details.isp;
      txtTimezone.innerText = details.timezone;
    } else {
      setFailedInfo();
    }
  });

  function setLoadingInfo() {
    txtCountry.innerText = "đang tải...";
    txtCity.innerText = "đang tải...";
    txtIsp.innerText = "đang tải...";
    txtTimezone.innerText = "đang tải...";
  }

  function setFailedInfo() {
    txtCountry.innerText = "thất bại";
    txtCity.innerText = "thất bại";
    txtIsp.innerText = "thất bại";
    txtTimezone.innerText = "thất bại";
  }

  btnOptimize.addEventListener("click", async () => {
    let ip = sanitizeIpInput(ipInput.value);
    ipInput.value = ip;
    let port = portInput.value.trim();
    let info = new ProxyInformation(ip, port);
    if (!info.checkDataAvailable()) return;

    // đo qua chính proxy (tạm áp cấu hình proxy này để test) thay vì ping tới
    // 1 server cố định không liên quan như bản cũ — số hiển thị giờ phản ánh
    // đúng tốc độ thật của proxy đang nhập, đổi lại sẽ gián đoạn proxy đang
    // kết nối (nếu có) trong vài giây khi đo
    txtLatency.innerText = "đang đo qua proxy...";
    txtAdvice.innerText = "đang đo...";

    let optimizer = new OptimizeConnect(ip, port, schemeSelect.value);
    let latency = await optimizer.checkLatency();
    txtLatency.innerText = latency;
    txtAdvice.innerText = optimizer.getOptimizationAdvice(latency);
  });

  // ==== Đánh giá proxy (checklist chẩn đoán, không tự sửa/giả mạo gì) ====

  const RATE_LABELS = { clean: "Clean", warn: "Warn", leak: "Leak", unknown: "Unknown", na: "N/A" };

  // check rò rỉ IP qua WebRTC — PHẢI chạy trong popup (RTCPeerConnection
  // không tồn tại trong service worker của background), khác các check còn
  // lại đều chạy qua ProxyRater ở background
  function checkWebRTCLeak() {
    return new Promise((resolve) => {
      if (typeof RTCPeerConnection === "undefined") {
        resolve({ status: "unknown", detail: "trình duyệt không hỗ trợ kiểm tra WebRTC" });
        return;
      }

      try {
        let pc = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }] });
        let foundIps = new Set();
        let done = false;

        function finish() {
          if (done) return;
          done = true;
          try { pc.close(); } catch (e) { /* đã đóng rồi thì thôi */ }

          if (foundIps.size === 0) {
            resolve({ status: "clean", detail: "không thu được ICE candidate nào lộ IP thật" });
          } else {
            resolve({ status: "leak", detail: `lộ qua WebRTC: ${Array.from(foundIps).join(", ")}` });
          }
        }

        pc.createDataChannel("pm-webrtc-test");
        pc.onicecandidate = (event) => {
          if (!event.candidate) { finish(); return; }
          // format chuẩn: "candidate:<foundation> <component> <transport> <priority> <address> <port> typ <type>..."
          let parts = event.candidate.candidate.split(" ");
          let addr = parts.length > 4 ? parts[4] : null;
          // bỏ qua candidate dạng mDNS (*.local) — đây là chrome đã tự ẩn IP
          // thật rồi, không phải rò rỉ
          if (addr && !addr.endsWith(".local")) foundIps.add(addr);
        };
        pc.createOffer().then((offer) => pc.setLocalDescription(offer)).catch(finish);

        setTimeout(finish, 3000); // đề phòng onicecandidate không tự báo hết (candidate=null)
      } catch (error) {
        resolve({ status: "unknown", detail: "không kiểm tra được WebRTC" });
      }
    });
  }

  function escapeHtmlRate(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function renderRatingResults(bgResult, webrtcResult) {
    let rows = [
      { name: "HTTP Headers Test", result: bgResult.headers },
      { name: "TOR Detection Test", result: bgResult.tor },
      {
        name: "TCP/IP Fingerprint Test",
        result: { status: "na", detail: "không kiểm tra được — do OS của MÁY CHỦ proxy tạo ra, extension không với tới được" }
      },
      { name: "Latency Test", result: bgResult.latency },
      { name: "Timezone Test", result: bgResult.timezone },
      { name: "WebRTC IP Leak Test", result: webrtcResult },
      {
        name: "Network Flow Pattern Test",
        result: { status: "na", detail: "không phải tín hiệu tự đo được — cần phân tích phía server theo thời gian" }
      },
      { name: "Hide IPv6", result: bgResult.ipv6 }
    ];

    let testedRows = rows.filter((r) => r.result.status !== "na");
    let cleanCount = testedRows.filter((r) => r.result.status === "clean").length;
    let leakCount = testedRows.filter((r) => r.result.status === "leak").length;

    rateSummary.style.display = "flex";
    rateSummary.classList.remove("good", "mixed", "bad");
    rateSummary.classList.add(leakCount === 0 ? "good" : leakCount <= 2 ? "mixed" : "bad");
    rateSummary.innerHTML = `<span>Kết quả</span><span>${cleanCount}/${testedRows.length} clean</span>`;

    rateList.innerHTML = rows.map((row) => `
      <div class="rate-row">
        <div class="rate-row-top">
          <span class="rate-name">${escapeHtmlRate(row.name)}</span>
          <span class="rate-badge rate-${row.result.status}">${RATE_LABELS[row.result.status] || row.result.status}</span>
        </div>
        ${row.result.detail ? `<div class="rate-detail">${escapeHtmlRate(row.result.detail)}</div>` : ""}
      </div>
    `).join("");
  }

  btnRateProxy.addEventListener("click", async () => {
    let ip = sanitizeIpInput(ipInput.value);
    ipInput.value = ip;
    let port = portInput.value.trim();

    let info = new ProxyInformation(ip, port);
    if (!info.checkDataAvailable()) return;

    // "auto" không tự dùng để set chrome.proxy.settings được (cần scheme cụ
    // thể) — ưu tiên scheme đã xác định lúc connect gần nhất, không thì mới
    // rơi về http làm mặc định hợp lý nhất
    let stored = await new Promise((resolve) => chrome.storage.local.get(["scheme"], resolve));
    let scheme = schemeSelect.value !== "auto" ? schemeSelect.value : (stored.scheme || "http");

    btnRateProxy.disabled = true;
    btnRateProxy.innerText = "đang đánh giá (~5-8s)...";
    rateSummary.style.display = "none";
    rateList.innerHTML = "";

    let [bgResult, webrtcResult] = await Promise.all([
      sendMessageAsync({ action: "runProxyRating", ip, port, scheme }),
      checkWebRTCLeak()
    ]);

    btnRateProxy.disabled = false;
    btnRateProxy.innerText = "Chạy Đánh Giá";

    if (!bgResult || bgResult.error) {
      rateList.innerHTML = `<div class="chart-empty">${escapeHtmlRate((bgResult && bgResult.error) || "có lỗi xảy ra khi đánh giá")}</div>`;
      return;
    }

    renderRatingResults(bgResult, webrtcResult);
  });

  btnConnect.addEventListener("click", async () => {
    let ip = sanitizeIpInput(ipInput.value);
    ipInput.value = ip;
    let port = portInput.value.trim();
    let user = userInput.value.trim();
    let pass = passInput.value.trim();
    let ruleMode = ruleModeSelect.value;
    let chosenScheme = schemeSelect.value; // "auto" | "http" | "https" | "socks5"
    let rawDomains = domainsToString();
    let domainsArray = [...domains];

    let info = new ProxyInformation(ip, port);
    if (!info.checkDataAvailable()) return;

    btnConnect.disabled = true;
    renderDetectLog([]);

    // lưu user/pass TRƯỚC khi gọi background, vì onAuthRequired đọc credentials
    // này ngay trong lúc dò/verify — thiếu bước này thì proxy có auth sẽ luôn
    // bị detect nhầm là "không hoạt động"
    await chrome.storage.local.set({ ip, port, user, pass, ruleMode, domains: rawDomains });

    // toàn bộ luồng dò scheme (nếu auto) -> connect -> verify giờ chạy hẳn
    // trong background (xem connectAndVerify), không còn phụ thuộc popup
    // phải mở xuyên suốt — trước đây verify chạy trong popup nên bấm connect
    // rồi lỡ tay đóng popup là mất luôn kết quả, đúng kiểu "ngắt đột ngột
    // không trả về dữ liệu"
    let result = await sendMessageAsync({
      action: "connectAndVerify", ip, port, domains: domainsArray, ruleMode, scheme: chosenScheme
    });

    btnConnect.disabled = false;
    renderDetectLog((result && result.log) || []);

    if (result && result.success) {
      renderRotateEstimate([], null); // vừa connect mới, lịch sử xoay được reset ở background
    }
    // các trường hợp khác: status/màu sắc đã được background ghi vào storage
    // và tự phản ánh qua chrome.storage.onChanged bên dưới, không cần set lại ở đây
  });

  btnDisconnect.addEventListener("click", async () => {
    await sendMessageAsync({ action: "disconnectProxy" });
    renderStatus("chưa kết nối");
    chrome.storage.local.set({ status: "chưa kết nối" });
  });

  function sendMessageAsync(message) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(message, (response) => resolve(response));
    });
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") return;
    if (changes.status) {
      renderStatus(changes.status.newValue);
    }
    if (changes.dataUsedBytes) {
      txtDataUsed.innerText = formatBytes(changes.dataUsedBytes.newValue);
    }
    if (changes.rotateHistory || changes.lastRotateAt) {
      chrome.storage.local.get(["rotateHistory", "lastRotateAt"], (data) => {
        renderRotateEstimate(data.rotateHistory, data.lastRotateAt);
      });
    }
    if (changes.dataUsedByDay || changes.connectTimeByDay) {
      scheduleLoadUsageStats();
    }
  });
});
