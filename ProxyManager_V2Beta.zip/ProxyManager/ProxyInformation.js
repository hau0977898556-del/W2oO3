if (!globalThis.ProxyInformation) {
  globalThis.ProxyInformation = class ProxyInformation {
    constructor(ip, port) {
      this.ip = ip;
      this.port = port;
    }

    static parseBulkProxy(rawString) {
      let cleanStr = rawString.trim();
      let parts = cleanStr.split(":");
      if (parts.length < 2) return null;
      return {
        ip: parts[0] ? parts[0].trim() : "",
        port: parts[1] ? parts[1].trim() : "",
        user: parts[2] ? parts[2].trim() : "",
        pass: parts[3] ? parts[3].trim() : ""
      };
    }

    checkDataAvailable() {
      if (!this.ip || !this.port) {
        alert("lỗi: vui lòng điền hoặc nhập đúng định dạng ip và port");
        return false;
      }
      return true;
    }

    // dùng https thay vì http để tránh mixed-content bị chặn
    async getDetailedInfo() {
      try {
        let controller = new AbortController();
        let timeoutId = setTimeout(() => controller.abort(), 6000);
        let response = await fetch(`https://ip-api.com/json/${this.ip}`, { signal: controller.signal });
        clearTimeout(timeoutId);
        let data = await response.json();
        if (data && data.status === "success") {
          return {
            country: `${data.country} (${data.countryCode})`,
            city: data.city || "không rõ",
            isp: data.isp || "không rõ",
            timezone: data.timezone || "không rõ"
          };
        }
        return null;
      } catch (error) {
        return null;
      }
    }

    async verifyActiveProxy() {
      try {
        let controller = new AbortController();
        let timeoutId = setTimeout(() => controller.abort(), 6000);
        let response = await fetch("https://api.ipify.org?format=json", { signal: controller.signal });
        clearTimeout(timeoutId);
        let data = await response.json();
        if (data && data.ip) {
          return { success: true, ip: data.ip };
        }
        return { success: false };
      } catch (error) {
        return { success: false };
      }
    }
  };
}
