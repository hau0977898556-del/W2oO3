// ProxyProbe: dò giao thức thật sự của 1 proxy (http / socks5 / https) và đo
// độ trễ thật qua chính proxy đó. Chỉ chạy trong background (service worker)
// vì cần chrome.proxy.settings + chrome.webRequest — KHÔNG load vào popup.
//
// Vì sao viết lại thay vì fetch() + catch() đơn giản như bản cũ:
// 1. fetch() khi lỗi transport (sai scheme, sai port, TLS fail...) chỉ trả về
//    1 lỗi chung chung "Failed to fetch", không biết lý do thật là gì. Ở đây
//    dùng chrome.webRequest.onErrorOccurred để lấy đúng mã net::ERR_* của
//    chrome, từ đó suy luận được vì sao 1 scheme không hoạt động thay vì chỉ
//    biết "không hoạt động".
// 2. Mỗi lần đổi chrome.proxy.settings, chrome cần 1 khoảng trễ nhỏ để áp
//    dụng thật sự. Gọi fetch ngay lập tức có thể vẫn đi qua cấu hình CŨ và
//    cho ra kết quả sai — nghi đây là 1 nguyên nhân chính gây "không nhận
//    diện được" trong bản cũ.
// 3. 1 lần fail có thể chỉ là trục trặc mạng tạm thời (không phải do sai
//    scheme), nên mỗi scheme được thử tối đa 2 lần trước khi kết luận hẳn.
// 4. Mỗi lần thử dùng 1 URL có nonce riêng — vừa để chrome KHÔNG trả kết quả
//    cache từ lần thử scheme trước (cache không phân biệt theo proxy nào đã
//    phục vụ request), vừa để đối chiếu đúng request nào gây lỗi.
if (!globalThis.ProxyProbe) {
  globalThis.ProxyProbe = class ProxyProbe {
    // thứ tự thử: http phổ biến nhất (đa số proxy list ngoài chợ), kế đến
    // socks5 (residential/rotating proxy hay dùng), cuối cùng https thật
    // (tunnel TLS ngay tới chính proxy — hiếm gặp nhất trong thực tế)
    static SCHEME_ORDER = ["http", "socks5", "https"];
    static SCHEME_LABELS = { http: "HTTP", https: "HTTPS", socks5: "SOCKS5" };

    static PROBE_URL = "https://api.ipify.org";
    static ERROR_FILTER_URLS = ["https://api.ipify.org/*"];

    static ATTEMPTS_PER_SCHEME = 2;
    static LATENCY_SAMPLE_COUNT = 3;
    static FETCH_TIMEOUT_MS = 6000;
    static RETRY_GAP_MS = 400;
    static SETTLE_DELAY_MS = 250;
    static ERROR_GRACE_MS = 120;
    static MAX_TOTAL_BUDGET_MS = 20000; // trần tổng thời gian cho 1 lần detectScheme()

    // map mã lỗi net::ERR_* của chrome sang giải thích tiếng việt dễ hiểu.
    // isDnsFailure=true nghĩa là lỗi này chắc chắn giống nhau ở MỌI scheme
    // (lỗi phân giải địa chỉ xảy ra trước khi có bất kỳ giao thức nào được
    // dùng tới), nên gặp là dừng luôn, thử tiếp các scheme khác chỉ tốn thời gian.
    static NET_ERROR_MAP = {
      "net::ERR_NAME_NOT_RESOLVED": { text: "không phân giải được địa chỉ (IP/host sai)", isDnsFailure: true },
      "net::ERR_NAME_RESOLUTION_FAILED": { text: "phân giải DNS thất bại", isDnsFailure: true },
      "net::ERR_ADDRESS_UNREACHABLE": { text: "không thể tới được địa chỉ này", isDnsFailure: true },
      "net::ERR_CONNECTION_REFUSED": { text: "cổng từ chối kết nối (sai port hoặc proxy đã tắt)" },
      "net::ERR_CONNECTION_RESET": { text: "kết nối bị reset giữa chừng" },
      "net::ERR_CONNECTION_CLOSED": { text: "proxy đóng kết nối đột ngột" },
      "net::ERR_CONNECTION_FAILED": { text: "không thiết lập được kết nối" },
      "net::ERR_CONNECTION_ABORTED": { text: "kết nối bị hủy giữa chừng" },
      "net::ERR_CONNECTION_TIMED_OUT": { text: "kết nối quá thời gian chờ (firewall hoặc proxy quá tải)" },
      "net::ERR_TIMED_OUT": { text: "quá thời gian chờ phản hồi" },
      "net::ERR_INTERNET_DISCONNECTED": { text: "máy đang mất kết nối internet" },
      "net::ERR_PROXY_CONNECTION_FAILED": { text: "không kết nối được tới proxy với giao thức này" },
      "net::ERR_TUNNEL_CONNECTION_FAILED": { text: "proxy từ chối tạo tunnel (có thể do sai xác thực hoặc chặn đích)" },
      "net::ERR_PROXY_AUTH_UNSUPPORTED": { text: "kiểu xác thực mà proxy yêu cầu không được hỗ trợ" },
      "net::ERR_PROXY_CERTIFICATE_INVALID": { text: "chứng chỉ TLS của proxy không hợp lệ" },
      "net::ERR_SOCKS_CONNECTION_FAILED": { text: "bắt tay SOCKS5 thất bại (không phải SOCKS5 hoặc sai thông tin đăng nhập)" },
      "net::ERR_SOCKS_CONNECTION_HOST_UNREACHABLE": { text: "SOCKS5 phản hồi nhưng báo không tới được đích" },
      "net::ERR_SOCKET_NOT_CONNECTED": { text: "socket chưa kết nối được tới proxy" },
      "net::ERR_SSL_PROTOCOL_ERROR": { text: "bắt tay TLS thất bại (proxy không nói HTTPS ở cổng này)" },
      "net::ERR_SSL_VERSION_OR_CIPHER_MISMATCH": { text: "TLS không tương thích (khó là proxy kiểu HTTPS thật)" },
      "net::ERR_CERT_COMMON_NAME_INVALID": {
        text: "TLS bắt tay được nhưng chứng chỉ không khớp IP (thường do provider dùng domain riêng chứ không phải IP) — nhiều khả năng ĐÚNG là HTTPS proxy"
      },
      "net::ERR_CERT_AUTHORITY_INVALID": {
        text: "TLS bắt tay được nhưng chứng chỉ không đáng tin (có thể tự ký) — nhiều khả năng ĐÚNG là HTTPS proxy nhưng chrome chặn cert"
      },
      "net::ERR_EMPTY_RESPONSE": { text: "proxy đóng kết nối mà không trả dữ liệu" },
      "net::ERR_HTTP2_PROTOCOL_ERROR": { text: "lỗi giao thức HTTP/2 khi nói chuyện với proxy" },
      "net::ERR_NETWORK_ACCESS_DENIED": { text: "hệ điều hành/firewall chặn kết nối này" },
      "net::ERR_INVALID_ARGUMENT": { text: "tham số kết nối không hợp lệ" }
    };

    constructor(ip, port) {
      this.ip = ProxyProbe.sanitizeIp(ip);
      this.port = parseInt(port);
      this.log = [];
      this._capturedError = null;
      this._boundErrorListener = null;
    }

    static sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }

    static labelFor(scheme) {
      return ProxyProbe.SCHEME_LABELS[scheme] || (scheme || "").toUpperCase();
    }

    // dọn ip nếu user lỡ dán nguyên chuỗi kiểu "http://1.2.3.4/" hoặc
    // "socks5://1.2.3.4" từ 1 list proxy nào đó — chrome.proxy.settings cần
    // host trần, dính scheme/slash thừa vào sẽ khiến toàn bộ việc dò/connect
    // âm thầm sai mà không có lỗi rõ ràng nào được báo ra
    static sanitizeIp(rawIp) {
      return (rawIp || "").trim()
        .replace(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//, "")
        .replace(/\/+$/, "");
    }

    // ================= API công khai =================

    // dò lần lượt http -> socks5 -> https, dừng ngay khi tìm được 1 cái xác nhận được
    async detectScheme() {
      this.log = [];
      this._log("info", `bắt đầu dò giao thức cho ${this.ip}:${this.port}`);

      if (!this._isValidTarget()) {
        this._log("fatal", "IP hoặc port không hợp lệ, hủy dò");
        return this._buildResult(null, null);
      }

      let startedAt = Date.now();
      let snapshot = await this._snapshotConfig();

      try {
        for (let scheme of ProxyProbe.SCHEME_ORDER) {
          if (Date.now() - startedAt > ProxyProbe.MAX_TOTAL_BUDGET_MS) {
            this._log("fatal", "hết thời gian tổng thể cho phép, dừng dò các giao thức còn lại");
            break;
          }

          let outcome = await this._probeScheme(scheme);

          if (outcome.confirmed) {
            let suffix = outcome.needsAuth ? " (cần user/pass đúng)" : "";
            this._log("success", `${ProxyProbe.labelFor(scheme)} phản hồi hợp lệ sau ${outcome.latencyMs}ms${suffix}`);
            return this._buildResult(scheme, outcome);
          }

          if (outcome.dnsFailure) {
            this._log("fatal", "lỗi phân giải địa chỉ giống nhau ở mọi giao thức, dừng lại sớm");
            break;
          }
        }

        this._log("fatal", "không xác định được giao thức nào hoạt động");
        return this._buildResult(null, null);
      } finally {
        // luôn khôi phục cấu hình gốc dù thành công, thất bại, hay lỗi giữa
        // chừng — tránh để trình duyệt kẹt ở cấu hình proxy test dở dang
        await this._restoreConfig(snapshot);
      }
    }

    // đo độ trễ THẬT qua đúng scheme được chỉ định (không tự dò lại từ đầu).
    // khác bản cũ: bản cũ "đo độ trễ" thực chất chỉ ping tới ip-api.com, không
    // hề đi qua proxy đang test — kết quả không phản ánh đúng chất lượng proxy.
    async measureLatency(scheme) {
      this.log = [];

      if (!this._isValidTarget()) {
        return { success: false, error: "target không hợp lệ", log: this.log };
      }
      if (!ProxyProbe.SCHEME_ORDER.includes(scheme)) {
        return { success: false, error: "scheme không hợp lệ", log: this.log };
      }

      let snapshot = await this._snapshotConfig();

      try {
        let applied = await this._applyTempConfig(scheme);
        if (!applied) {
          this._log("fatal", "không set được cấu hình proxy tạm thời (extension khác đang giữ quyền quản lý proxy?)");
          return { success: false, error: "không áp dụng được cấu hình proxy", log: this.log };
        }

        await ProxyProbe.sleep(ProxyProbe.SETTLE_DELAY_MS);

        let samples = [];
        for (let i = 0; i < ProxyProbe.LATENCY_SAMPLE_COUNT; i++) {
          let outcome = await this._singleAttempt(scheme, i + 1);
          if (outcome.confirmed && typeof outcome.latencyMs === "number") {
            samples.push(outcome.latencyMs);
          }
          if (i < ProxyProbe.LATENCY_SAMPLE_COUNT - 1) await ProxyProbe.sleep(ProxyProbe.RETRY_GAP_MS);
        }

        if (samples.length === 0) {
          return { success: false, error: "không kết nối được để đo độ trễ", log: this.log };
        }

        // lấy trung vị thay vì trung bình để 1 mẫu đột biến (do mạng giật)
        // không kéo lệch kết quả hiển thị cho người dùng
        samples.sort((a, b) => a - b);
        let median = samples[Math.floor(samples.length / 2)];
        return { success: true, latencyMs: median, samples, log: this.log };
      } finally {
        await this._restoreConfig(snapshot);
      }
    }

    // ================= vòng lặp thử theo scheme =================

    async _probeScheme(scheme) {
      let applied = await this._applyTempConfig(scheme);
      if (!applied) {
        this._log("fatal", `không set được cấu hình cho ${ProxyProbe.labelFor(scheme)} (extension khác đang giữ quyền quản lý proxy?)`);
        return { confirmed: false };
      }

      // chờ chrome áp dụng cấu hình mới thật sự trước khi bắn request test,
      // tránh trường hợp request đầu tiên vẫn còn đi theo cấu hình CŨ và cho
      // kết quả dương tính giả hoặc âm tính giả
      await ProxyProbe.sleep(ProxyProbe.SETTLE_DELAY_MS);

      let lastOutcome = { confirmed: false };
      for (let attempt = 1; attempt <= ProxyProbe.ATTEMPTS_PER_SCHEME; attempt++) {
        lastOutcome = await this._singleAttempt(scheme, attempt);
        if (lastOutcome.confirmed || lastOutcome.dnsFailure) return lastOutcome;
        if (attempt < ProxyProbe.ATTEMPTS_PER_SCHEME) await ProxyProbe.sleep(ProxyProbe.RETRY_GAP_MS);
      }
      return lastOutcome;
    }

    async _singleAttempt(scheme, attemptNumber) {
      // nonce vừa để cache-bust (đảm bảo lần thử này chắc chắn ra mạng thật,
      // không bị chrome trả kết quả cache từ lần thử scheme khác trước đó)
      // vừa để đối chiếu đúng request nào gây lỗi trong onErrorOccurred
      let nonce = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      let testUrl = `${ProxyProbe.PROBE_URL}?format=json&_p=${nonce}`;

      this._armErrorListener(nonce);
      let startedAt = Date.now();
      let controller = new AbortController();
      let timeoutId = setTimeout(() => controller.abort(), ProxyProbe.FETCH_TIMEOUT_MS);

      try {
        let res = await fetch(testUrl, { signal: controller.signal, cache: "no-store" });
        clearTimeout(timeoutId);
        let latencyMs = Date.now() - startedAt;

        // 407 nghĩa là chrome ĐÃ nói chuyện thành công với proxy ở tầng
        // transport, chỉ là thiếu/sai user-pass — vẫn tính là xác nhận đúng
        // giao thức, vì bản thân việc nhận được 1 phản hồi HTTP hợp lệ (dù
        // là lỗi auth) chứng minh proxy hiểu đúng giao thức đang test
        if (res.status === 407) {
          this._log("warn", `${ProxyProbe.labelFor(scheme)} lần ${attemptNumber}: proxy yêu cầu xác thực (407)`);
          return { confirmed: true, needsAuth: true, latencyMs, scheme };
        }

        let data = await res.json().catch(() => null);
        if (data && data.ip) {
          return { confirmed: true, latencyMs, scheme, exitIp: data.ip };
        }

        this._log("warn", `${ProxyProbe.labelFor(scheme)} lần ${attemptNumber}: phản hồi không hợp lệ (status ${res.status})`);
        return { confirmed: false };
      } catch (error) {
        clearTimeout(timeoutId);
        // chờ 1 nhịp ngắn để onErrorOccurred (bất đồng bộ, tách rời khỏi
        // promise của fetch) kịp bắn ra trước khi mình đọc _capturedError
        await ProxyProbe.sleep(ProxyProbe.ERROR_GRACE_MS);

        let reason = this._classify(error, this._capturedError);
        this._log("error", `${ProxyProbe.labelFor(scheme)} lần ${attemptNumber}: ${reason.text}`);
        return { confirmed: false, dnsFailure: reason.isDnsFailure };
      } finally {
        this._disarmErrorListener();
      }
    }

    // ================= vòng đời cấu hình proxy =================

    _snapshotConfig() {
      return new Promise((resolve) => {
        chrome.proxy.settings.get({}, (details) => resolve(details.value));
      });
    }

    _restoreConfig(snapshotValue) {
      return new Promise((resolve) => {
        chrome.proxy.settings.set({ value: snapshotValue, scope: "regular" }, () => resolve());
      });
    }

    _applyTempConfig(scheme) {
      return new Promise((resolve) => {
        let config = {
          mode: "fixed_servers",
          rules: {
            singleProxy: { scheme, host: this.ip, port: this.port },
            bypassList: ["localhost", "127.0.0.1"]
          }
        };
        chrome.proxy.settings.set({ value: config, scope: "regular" }, () => {
          resolve(!chrome.runtime.lastError);
        });
      });
    }

    // ================= bắt lỗi mạng chi tiết qua webRequest =================

    _armErrorListener(nonce) {
      this._capturedError = null;
      this._boundErrorListener = (details) => {
        if (details.url && details.url.includes(nonce)) {
          this._capturedError = details.error;
        }
      };
      chrome.webRequest.onErrorOccurred.addListener(
        this._boundErrorListener,
        { urls: ProxyProbe.ERROR_FILTER_URLS }
      );
    }

    _disarmErrorListener() {
      if (this._boundErrorListener) {
        chrome.webRequest.onErrorOccurred.removeListener(this._boundErrorListener);
        this._boundErrorListener = null;
      }
    }

    // ================= phân loại lỗi =================

    _classify(fetchError, netErrorString) {
      if (netErrorString) {
        let matched = ProxyProbe.NET_ERROR_MAP[netErrorString];
        if (matched) return { text: `${matched.text} [${netErrorString}]`, isDnsFailure: !!matched.isDnsFailure };
        return { text: `lỗi mạng: ${netErrorString}`, isDnsFailure: false };
      }

      if (fetchError && fetchError.name === "AbortError") {
        return { text: "hết thời gian chờ phản hồi", isDnsFailure: false };
      }

      return { text: `lỗi không xác định (${fetchError ? fetchError.message : "?"})`, isDnsFailure: false };
    }

    // ================= helpers =================

    _isValidTarget() {
      if (!this.ip) return false;
      if (!Number.isInteger(this.port) || this.port <= 0 || this.port > 65535) return false;
      return true;
    }

    _log(level, text) {
      this.log.push({ level, text, at: Date.now() });
    }

    _buildResult(scheme, outcome) {
      return {
        scheme: scheme || null,
        needsAuth: !!(outcome && outcome.needsAuth),
        exitIp: (outcome && outcome.exitIp) || null,
        latencyMs: (outcome && outcome.latencyMs) || null,
        log: this.log
      };
    }
  };
}
