// css cho widget nổi + thông báo lỗi/đổi ip, tông xanh biển
let styleTag = document.createElement("style");
styleTag.textContent = `
  #proxy-manager-widget {
    position: fixed !important;
    top: 15px !important;
    right: 15px !important;
    z-index: 2147483647 !important;
    background: rgba(15, 25, 40, 0.55) !important;
    backdrop-filter: blur(10px) !important;
    -webkit-backdrop-filter: blur(10px) !important;
    color: #eaf6ff !important;
    padding: 8px 12px !important;
    border-radius: 10px !important;
    box-shadow: 0 4px 20px rgba(0,0,0,0.25) !important;
    font-family: Arial, sans-serif !important;
    font-size: 12px !important;
    display: flex !important;
    align-items: center !important;
    gap: 10px !important;
    border: 1px solid rgba(79, 195, 247, 0.25) !important;
    pointer-events: auto !important;
    user-select: none !important;
  }
  #pmw-ping {
    font-weight: bold !important;
    color: #4fc3f7 !important;
  }
  #pmw-toggle {
    background: #2f8fae !important;
    color: #ffffff !important;
    border: none !important;
    padding: 4px 8px !important;
    border-radius: 6px !important;
    cursor: pointer !important;
    font-weight: bold !important;
    font-size: 11px !important;
    transition: background 0.2s !important;
  }
  #pmw-toggle:hover { background: #26788f !important; }
  #pmw-toggle.active { background: #d9433f !important; }
  #pmw-toggle.active:hover { background: #b8342f !important; }
  #pmw-toggle:disabled { opacity: 0.6 !important; cursor: wait !important; }

  #proxy-float-notif {
    position: fixed !important;
    top: 70px !important;
    right: 15px !important;
    z-index: 2147483647 !important;
    padding: 10px 15px !important;
    border-radius: 8px !important;
    font-family: Arial, sans-serif !important;
    font-size: 12px !important;
    font-weight: bold !important;
    box-shadow: 0 4px 16px rgba(0,0,0,0.2) !important;
    animation: pmw-slide-in 0.35s ease-out !important;
    max-width: 260px !important;
  }
  #proxy-float-notif.pmw-error {
    background: rgba(60, 20, 20, 0.85) !important;
    color: #ffb4b0 !important;
    border: 1px solid rgba(217, 67, 63, 0.4) !important;
  }
  #proxy-float-notif.pmw-rotate {
    background: rgba(12, 35, 55, 0.88) !important;
    color: #bfe8ff !important;
    border: 1px solid rgba(79, 195, 247, 0.4) !important;
  }
  #proxy-float-notif.pmw-fade-out {
    animation: pmw-fade-out 0.4s ease-in forwards !important;
  }
  @keyframes pmw-slide-in {
    from { opacity: 0; transform: translateX(30px); }
    to { opacity: 1; transform: translateX(0); }
  }
  @keyframes pmw-fade-out {
    from { opacity: 1; transform: translateX(0); }
    to { opacity: 0; transform: translateX(30px); }
  }
`;
document.head.appendChild(styleTag);

// widget nổi góc phải trên
let widget = document.createElement("div");
widget.id = "proxy-manager-widget";

let pingSpan = document.createElement("span");
pingSpan.id = "pmw-ping";
pingSpan.innerText = "ping: --";
widget.appendChild(pingSpan);

let toggleBtn = document.createElement("button");
toggleBtn.id = "pmw-toggle";
toggleBtn.innerText = "bật";
widget.appendChild(toggleBtn);

document.body.appendChild(widget);

let isProxyActive = false;

function updateWidgetState() {
  chrome.storage.local.get(["status", "currentPing"], (data) => {
    let status = data.status || "";
    if (status.includes("Proxy working")) {
      isProxyActive = true;
      toggleBtn.disabled = false;
      toggleBtn.innerText = "tắt";
      toggleBtn.classList.add("active");
      pingSpan.innerText = `ping: ${data.currentPing || "--"}`;
    } else if (status.includes("đang")) {
      // trạng thái trung gian (đang dò giao thức / đang kích hoạt) — khóa nút
      // lại để tránh bấm chồng, dù request connect đến từ popup hay từ chính
      // nút nổi này
      toggleBtn.disabled = true;
      toggleBtn.innerText = "đang...";
      pingSpan.innerText = "ping: --";
    } else {
      isProxyActive = false;
      toggleBtn.disabled = false;
      toggleBtn.innerText = "bật";
      toggleBtn.classList.remove("active");
      pingSpan.innerText = "ping: --";
    }
  });
}

toggleBtn.addEventListener("click", () => {
  if (isProxyActive) {
    chrome.runtime.sendMessage({ action: "disconnectProxy" }, () => {
      chrome.storage.local.set({ status: "chưa kết nối", currentPing: "" }, updateWidgetState);
    });
  } else {
    // đọc đủ domains/ruleMode/scheme đã lưu thay vì chỉ ip/port — bản cũ bỏ
    // sót các trường này nên bấm nút nổi sẽ âm thầm connect lại với mặc định
    // HTTP + không lọc domain, phá mất cấu hình người dùng đã thiết lập
    chrome.storage.local.get(["ip", "port", "domains", "ruleMode", "scheme"], (data) => {
      if (data.ip && data.port) {
        toggleBtn.disabled = true;
        toggleBtn.innerText = "đang...";
        let domainsArray = (data.domains || "").split(",").map(d => d.trim()).filter(Boolean);

        // dùng connectAndVerify (chạy trong background, có verify thật) thay vì
        // tự set status "Proxy working" ngay lập tức mà không kiểm tra gì —
        // bản cũ làm vậy nên widget báo "đang chạy" dù proxy thực ra chết
        chrome.runtime.sendMessage({
          action: "connectAndVerify",
          ip: data.ip,
          port: data.port,
          domains: domainsArray,
          ruleMode: data.ruleMode || "blacklist",
          scheme: data.scheme || "auto"
        }, () => {
          toggleBtn.disabled = false;
          updateWidgetState();
        });
      } else {
        alert("vui lòng mở popup tiện ích để cấu hình địa chỉ ip và cổng trước");
      }
    });
  }
});

// hiển thị thông báo nổi có hiệu ứng slide-in/fade-out, dùng chung cho lỗi và đổi ip
function showFloatNotif(message, type) {
  let existing = document.getElementById("proxy-float-notif");
  if (existing) existing.remove();

  let notif = document.createElement("div");
  notif.id = "proxy-float-notif";
  notif.className = type === "rotate" ? "pmw-rotate" : "pmw-error";
  notif.innerText = message;
  document.body.appendChild(notif);

  setTimeout(() => {
    notif.classList.add("pmw-fade-out");
    setTimeout(() => notif.remove(), 400);
  }, 6000);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "showError") {
    showFloatNotif(`cảnh báo: ${message.message}`, "error");
  }
  if (message.action === "ipRotated") {
    showFloatNotif(`proxy đã đổi ip mới: ${message.newIp}`, "rotate");
  }
  sendResponse({ received: true });
});

updateWidgetState();

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local") updateWidgetState();
});
