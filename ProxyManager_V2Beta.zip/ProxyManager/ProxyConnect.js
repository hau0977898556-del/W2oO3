if (!globalThis.ProxyConnect) {
  globalThis.ProxyConnect = class ProxyConnect {
    // scheme: "http" | "https" | "socks5" — quyết định cách chrome nói chuyện
    // với proxy ở tầng transport, không liên quan gì đến URL đích (http/https)
    constructor(ip, port, domains = [], ruleMode = "blacklist", scheme = "http") {
      // dọn trường hợp user dán nhầm nguyên chuỗi "http://1.2.3.4/" từ 1 list
      // proxy nào đó vào ô IP — chrome.proxy.settings cần host trần, dính
      // scheme/slash thừa sẽ khiến connect âm thầm sai không rõ nguyên nhân
      this.ip = (ip || "").trim().replace(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//, "").replace(/\/+$/, "");
      this.port = parseInt(port);
      this.domains = domains;
      this.ruleMode = ruleMode;
      this.scheme = scheme || "http";
    }

    // chrome.proxy dùng "socks5" cho fixed_servers.scheme, nhưng PAC script
    // (return string trong FindProxyForURL) lại cần prefix viết hoa riêng
    static pacPrefixFor(scheme) {
      if (scheme === "https") return "HTTPS";
      if (scheme === "socks5") return "SOCKS5";
      return "PROXY";
    }

    // người dùng có thể tự nhập domain kèm "*" (vd "*.google.com") hoặc domain
    // trần (vd "google.com"). Hàm này chuẩn hóa để tránh double-wildcard khi
    // ghép thêm "*" ở 2 đầu cho shExpMatch/bypassList.
    static normalizeDomainPattern(rawDomain, wrapBothSides) {
      let domain = rawDomain.trim();
      if (!domain) return "";
      if (domain.includes("*")) return domain; // user đã tự định nghĩa wildcard, giữ nguyên
      return wrapBothSides ? `*${domain}*` : `*${domain}`;
    }

    // tách build config riêng cho dễ đọc
    buildConfig() {
      let pacPrefix = ProxyConnect.pacPrefixFor(this.scheme);

      if (this.ruleMode === "whitelist" && this.domains.length > 0) {
        let whitelistArray = [...this.domains];
        if (!whitelistArray.includes("ipify.org")) whitelistArray.push("ipify.org");
        if (!whitelistArray.includes("ip-api.com")) whitelistArray.push("ip-api.com");

        let matchConditions = whitelistArray
          .map(domain => `shExpMatch(host, "${ProxyConnect.normalizeDomainPattern(domain, true)}")`)
          .join(" || ");

        let pacScriptCode = `
          function FindProxyForURL(url, host) {
            if (${matchConditions}) {
              return "${pacPrefix} ${this.ip}:${this.port}";
            }
            return "DIRECT";
          }
        `;

        return { mode: "pac_script", pacScript: { data: pacScriptCode } };
      }

      let bypassList = ["localhost", "127.0.0.1"];
      if (this.ruleMode === "blacklist" && this.domains.length > 0) {
        this.domains.forEach(domain => {
          bypassList.push(ProxyConnect.normalizeDomainPattern(domain, false));
        });
      }

      return {
        mode: "fixed_servers",
        rules: {
          singleProxy: { scheme: this.scheme, host: this.ip, port: this.port },
          bypassList: bypassList
        }
      };
    }

    // trả promise, chờ chrome apply config xong mới resolve
    // để chỗ gọi connect() có thể await trước khi verify
    connect() {
      return new Promise((resolve) => {
        let config = this.buildConfig();
        chrome.proxy.settings.set({ value: config, scope: "regular" }, () => {
          resolve(true);
        });
      });
    }

    disconnect() {
      return new Promise((resolve) => {
        chrome.proxy.settings.set({ value: { mode: "direct" }, scope: "regular" }, () => {
          resolve(true);
        });
      });
    }
  };
}
